package com.bytatech.aayos.patientservice.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.bytatech.aayos.patientservice.service.FamilyRelationShipService;
import com.bytatech.aayos.patientservice.web.rest.errors.BadRequestAlertException;
import com.bytatech.aayos.patientservice.web.rest.util.HeaderUtil;
import com.bytatech.aayos.patientservice.web.rest.util.PaginationUtil;
import com.bytatech.aayos.patientservice.service.dto.FamilyRelationShipDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing FamilyRelationShip.
 */
@RestController
@RequestMapping("/api")
public class FamilyRelationShipResource {

    private final Logger log = LoggerFactory.getLogger(FamilyRelationShipResource.class);

    private static final String ENTITY_NAME = "familyRelationShip";

    private final FamilyRelationShipService familyRelationShipService;

    public FamilyRelationShipResource(FamilyRelationShipService familyRelationShipService) {
        this.familyRelationShipService = familyRelationShipService;
    }

    /**
     * POST  /family-relation-ships : Create a new familyRelationShip.
     *
     * @param familyRelationShipDTO the familyRelationShipDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new familyRelationShipDTO, or with status 400 (Bad Request) if the familyRelationShip has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/family-relation-ships")
    @Timed
    public ResponseEntity<FamilyRelationShipDTO> createFamilyRelationShip(@RequestBody FamilyRelationShipDTO familyRelationShipDTO) throws URISyntaxException {
        log.debug("REST request to save FamilyRelationShip : {}", familyRelationShipDTO);
        if (familyRelationShipDTO.getId() != null) {
            throw new BadRequestAlertException("A new familyRelationShip cannot already have an ID", ENTITY_NAME, "idexists");
        }
        FamilyRelationShipDTO result = familyRelationShipService.save(familyRelationShipDTO);
        return ResponseEntity.created(new URI("/api/family-relation-ships/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /family-relation-ships : Updates an existing familyRelationShip.
     *
     * @param familyRelationShipDTO the familyRelationShipDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated familyRelationShipDTO,
     * or with status 400 (Bad Request) if the familyRelationShipDTO is not valid,
     * or with status 500 (Internal Server Error) if the familyRelationShipDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/family-relation-ships")
    @Timed
    public ResponseEntity<FamilyRelationShipDTO> updateFamilyRelationShip(@RequestBody FamilyRelationShipDTO familyRelationShipDTO) throws URISyntaxException {
        log.debug("REST request to update FamilyRelationShip : {}", familyRelationShipDTO);
        if (familyRelationShipDTO.getId() == null) {
            return createFamilyRelationShip(familyRelationShipDTO);
        }
        FamilyRelationShipDTO result = familyRelationShipService.save(familyRelationShipDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, familyRelationShipDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /family-relation-ships : get all the familyRelationShips.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of familyRelationShips in body
     */
    @GetMapping("/family-relation-ships")
    @Timed
    public ResponseEntity<List<FamilyRelationShipDTO>> getAllFamilyRelationShips(Pageable pageable) {
        log.debug("REST request to get a page of FamilyRelationShips");
        Page<FamilyRelationShipDTO> page = familyRelationShipService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/family-relation-ships");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }

    /**
     * GET  /family-relation-ships/:id : get the "id" familyRelationShip.
     *
     * @param id the id of the familyRelationShipDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the familyRelationShipDTO, or with status 404 (Not Found)
     */
    @GetMapping("/family-relation-ships/{id}")
    @Timed
    public ResponseEntity<FamilyRelationShipDTO> getFamilyRelationShip(@PathVariable Long id) {
        log.debug("REST request to get FamilyRelationShip : {}", id);
        FamilyRelationShipDTO familyRelationShipDTO = familyRelationShipService.findOne(id);
        return ResponseUtil.wrapOrNotFound(Optional.ofNullable(familyRelationShipDTO));
    }

    /**
     * DELETE  /family-relation-ships/:id : delete the "id" familyRelationShip.
     *
     * @param id the id of the familyRelationShipDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/family-relation-ships/{id}")
    @Timed
    public ResponseEntity<Void> deleteFamilyRelationShip(@PathVariable Long id) {
        log.debug("REST request to delete FamilyRelationShip : {}", id);
        familyRelationShipService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
