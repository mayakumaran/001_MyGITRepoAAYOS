package com.bytatech.aayos.patientservice.service.mapper;

import com.bytatech.aayos.patientservice.domain.*;
import com.bytatech.aayos.patientservice.service.dto.InsurarDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Insurar and its DTO InsurarDTO.
 */
@Mapper(componentModel = "spring", uses = {PatientMapper.class})
public interface InsurarMapper extends EntityMapper<InsurarDTO, Insurar> {

    @Mapping(source = "patient.id", target = "patientId")
    InsurarDTO toDto(Insurar insurar); 

    @Mapping(source = "patientId", target = "patient")
    @Mapping(target = "healthInsurances", ignore = true)
    Insurar toEntity(InsurarDTO insurarDTO);

    default Insurar fromId(Long id) {
        if (id == null) {
            return null;
        }
        Insurar insurar = new Insurar();
        insurar.setId(id);
        return insurar;
    }
}
