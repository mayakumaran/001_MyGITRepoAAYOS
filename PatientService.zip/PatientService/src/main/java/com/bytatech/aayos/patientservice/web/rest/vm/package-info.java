/**
 * View Models used by Spring MVC REST controllers.
 */
package com.bytatech.aayos.patientservice.web.rest.vm;
