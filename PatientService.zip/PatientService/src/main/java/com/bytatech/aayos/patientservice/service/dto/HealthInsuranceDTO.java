package com.bytatech.aayos.patientservice.service.dto;


import java.time.LocalDate;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A DTO for the HealthInsurance entity.
 */
public class HealthInsuranceDTO implements Serializable {

    private Long id;

    private Long insuranceNumber;

    private LocalDate expiraryDate;

    private Long insurarId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getInsuranceNumber() {
        return insuranceNumber;
    }

    public void setInsuranceNumber(Long insuranceNumber) {
        this.insuranceNumber = insuranceNumber;
    }

    public LocalDate getExpiraryDate() {
        return expiraryDate;
    }

    public void setExpiraryDate(LocalDate expiraryDate) {
        this.expiraryDate = expiraryDate;
    }

    public Long getInsurarId() {
        return insurarId;
    }

    public void setInsurarId(Long insurarId) {
        this.insurarId = insurarId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        HealthInsuranceDTO healthInsuranceDTO = (HealthInsuranceDTO) o;
        if(healthInsuranceDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), healthInsuranceDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "HealthInsuranceDTO{" +
            "id=" + getId() +
            ", insuranceNumber=" + getInsuranceNumber() +
            ", expiraryDate='" + getExpiraryDate() + "'" +
            "}";
    }
}
