package com.bytatech.aayos.patientservice.client.insuranceservice.model;

import java.util.Objects;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.InsuranceCategory;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.Insurer;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.Relationship;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;

/**
 * HealthInsurance
 */
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2018-03-14T11:48:59.500+05:30")

public class HealthInsurance   {
  @JsonProperty("category")
  private InsuranceCategory category = null;

  @JsonProperty("coverager")
  private String coverager = null;

  @JsonProperty("createdDate")
  private LocalDate createdDate = null;

  @JsonProperty("expiryDate")
  private LocalDate expiryDate = null;

  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("insuranceNumber")
  private Long insuranceNumber = null;

  @JsonProperty("insurer")
  private Insurer insurer = null;

  @JsonProperty("patientId")
  private Long patientId = null;

  @JsonProperty("status")
  private Relationship status = null;

  public HealthInsurance category(InsuranceCategory category) {
    this.category = category;
    return this;
  }

   /**
   * Get category
   * @return category
  **/
  @ApiModelProperty(value = "")
  public InsuranceCategory getCategory() {
    return category;
  }

  public void setCategory(InsuranceCategory category) {
    this.category = category;
  }

  public HealthInsurance coverager(String coverager) {
    this.coverager = coverager;
    return this;
  }

   /**
   * Get coverager
   * @return coverager
  **/
  @ApiModelProperty(value = "")
  public String getCoverager() {
    return coverager;
  }

  public void setCoverager(String coverager) {
    this.coverager = coverager;
  }

  public HealthInsurance createdDate(LocalDate createdDate) {
    this.createdDate = createdDate;
    return this;
  }

   /**
   * Get createdDate
   * @return createdDate
  **/
  @ApiModelProperty(value = "")
  public LocalDate getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(LocalDate createdDate) {
    this.createdDate = createdDate;
  }

  public HealthInsurance expiryDate(LocalDate expiryDate) {
    this.expiryDate = expiryDate;
    return this;
  }

   /**
   * Get expiryDate
   * @return expiryDate
  **/
  @ApiModelProperty(value = "")
  public LocalDate getExpiryDate() {
    return expiryDate;
  }

  public void setExpiryDate(LocalDate expiryDate) {
    this.expiryDate = expiryDate;
  }

  public HealthInsurance id(Long id) {
    this.id = id;
    return this;
  }

   /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(value = "")
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public HealthInsurance insuranceNumber(Long insuranceNumber) {
    this.insuranceNumber = insuranceNumber;
    return this;
  }

   /**
   * Get insuranceNumber
   * @return insuranceNumber
  **/
  @ApiModelProperty(value = "")
  public Long getInsuranceNumber() {
    return insuranceNumber;
  }

  public void setInsuranceNumber(Long insuranceNumber) {
    this.insuranceNumber = insuranceNumber;
  }

  public HealthInsurance insurer(Insurer insurer) {
    this.insurer = insurer;
    return this;
  }

   /**
   * Get insurer
   * @return insurer
  **/
  @ApiModelProperty(value = "")
  public Insurer getInsurer() {
    return insurer;
  }

  public void setInsurer(Insurer insurer) {
    this.insurer = insurer;
  }

  public HealthInsurance patientId(Long patientId) {
    this.patientId = patientId;
    return this;
  }

   /**
   * Get patientId
   * @return patientId
  **/
  @ApiModelProperty(value = "")
  public Long getPatientId() {
    return patientId;
  }

  public void setPatientId(Long patientId) {
    this.patientId = patientId;
  }

  public HealthInsurance status(Relationship status) {
    this.status = status;
    return this;
  }

   /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(value = "")
  public Relationship getStatus() {
    return status;
  }

  public void setStatus(Relationship status) {
    this.status = status;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HealthInsurance healthInsurance = (HealthInsurance) o;
    return Objects.equals(this.category, healthInsurance.category) &&
        Objects.equals(this.coverager, healthInsurance.coverager) &&
        Objects.equals(this.createdDate, healthInsurance.createdDate) &&
        Objects.equals(this.expiryDate, healthInsurance.expiryDate) &&
        Objects.equals(this.id, healthInsurance.id) &&
        Objects.equals(this.insuranceNumber, healthInsurance.insuranceNumber) &&
        Objects.equals(this.insurer, healthInsurance.insurer) &&
        Objects.equals(this.patientId, healthInsurance.patientId) &&
        Objects.equals(this.status, healthInsurance.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(category, coverager, createdDate, expiryDate, id, insuranceNumber, insurer, patientId, status);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HealthInsurance {\n");
    
    sb.append("    category: ").append(toIndentedString(category)).append("\n");
    sb.append("    coverager: ").append(toIndentedString(coverager)).append("\n");
    sb.append("    createdDate: ").append(toIndentedString(createdDate)).append("\n");
    sb.append("    expiryDate: ").append(toIndentedString(expiryDate)).append("\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    insuranceNumber: ").append(toIndentedString(insuranceNumber)).append("\n");
    sb.append("    insurer: ").append(toIndentedString(insurer)).append("\n");
    sb.append("    patientId: ").append(toIndentedString(patientId)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

