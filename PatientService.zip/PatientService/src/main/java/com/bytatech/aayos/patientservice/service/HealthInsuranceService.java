package com.bytatech.aayos.patientservice.service;

import com.bytatech.aayos.patientservice.service.dto.HealthInsuranceDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing HealthInsurance.
 */
public interface HealthInsuranceService {

    /**
     * Save a healthInsurance.
     *
     * @param healthInsuranceDTO the entity to save
     * @return the persisted entity
     */
    HealthInsuranceDTO save(HealthInsuranceDTO healthInsuranceDTO);

    /**
     * Get all the healthInsurances.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<HealthInsuranceDTO> findAll(Pageable pageable);

    /**
     * Get the "id" healthInsurance.
     *
     * @param id the id of the entity
     * @return the entity
     */
    HealthInsuranceDTO findOne(Long id);

    /**
     * Delete the "id" healthInsurance.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
