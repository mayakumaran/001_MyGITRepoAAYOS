package com.bytatech.aayos.patientservice.repository;

import com.bytatech.aayos.patientservice.domain.PrivateDetails;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.*;


/**
 * Spring Data JPA repository for the PrivateDetails entity.
 */
@SuppressWarnings("unused")
@Repository
public interface PrivateDetailsRepository extends JpaRepository<PrivateDetails, Long> {

}
