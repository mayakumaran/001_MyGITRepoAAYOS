package com.bytatech.aayos.patientservice.service.impl;

import com.bytatech.aayos.patientservice.service.PrivateDetailsService;
import com.bytatech.aayos.patientservice.domain.PrivateDetails;
import com.bytatech.aayos.patientservice.repository.PrivateDetailsRepository;
import com.bytatech.aayos.patientservice.service.dto.PrivateDetailsDTO;
import com.bytatech.aayos.patientservice.service.mapper.PrivateDetailsMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * Service Implementation for managing PrivateDetails.
 */
@Service
@Transactional
public class PrivateDetailsServiceImpl implements PrivateDetailsService{

    private final Logger log = LoggerFactory.getLogger(PrivateDetailsServiceImpl.class);

    private final PrivateDetailsRepository privateDetailsRepository;

    private final PrivateDetailsMapper privateDetailsMapper;

    public PrivateDetailsServiceImpl(PrivateDetailsRepository privateDetailsRepository, PrivateDetailsMapper privateDetailsMapper) {
        this.privateDetailsRepository = privateDetailsRepository;
        this.privateDetailsMapper = privateDetailsMapper;
    }

    /**
     * Save a privateDetails.
     *
     * @param privateDetailsDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public PrivateDetailsDTO save(PrivateDetailsDTO privateDetailsDTO) {
        log.debug("Request to save PrivateDetails : {}", privateDetailsDTO);
        PrivateDetails privateDetails = privateDetailsMapper.toEntity(privateDetailsDTO);
        privateDetails = privateDetailsRepository.save(privateDetails);
        return privateDetailsMapper.toDto(privateDetails);
    }

    /**
     * Get all the privateDetails.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<PrivateDetailsDTO> findAll(Pageable pageable) {
        log.debug("Request to get all PrivateDetails");
        return privateDetailsRepository.findAll(pageable)
            .map(privateDetailsMapper::toDto);
    }

    /**
     * Get one privateDetails by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public PrivateDetailsDTO findOne(Long id) {
        log.debug("Request to get PrivateDetails : {}", id);
        PrivateDetails privateDetails = privateDetailsRepository.findOne(id);
        return privateDetailsMapper.toDto(privateDetails);
    }

    /**
     * Delete the privateDetails by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete PrivateDetails : {}", id);
        privateDetailsRepository.delete(id);
    }
}
