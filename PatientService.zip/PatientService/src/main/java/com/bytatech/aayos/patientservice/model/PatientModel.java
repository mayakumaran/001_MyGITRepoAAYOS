 /*
 * Copyright 2002-2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bytatech.aayos.patientservice.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.bytatech.aayos.patientservice.domain.Booking;
import com.bytatech.aayos.patientservice.domain.Country;
import com.bytatech.aayos.patientservice.domain.FamilyRelationShip;
import com.bytatech.aayos.patientservice.domain.Gender;
import com.bytatech.aayos.patientservice.domain.Insurar;
import com.bytatech.aayos.patientservice.domain.PrivateDetails;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * TODO Provide a detailed description here 
 * @author MayaSanjeev
 * mayabytatech, maya.k.k@lxisoft.com
 */
public class PatientModel {
	
	    private Long id;
 
	  
	    private String firstName;

	  
	    private String lastName;

	   
	    private LocalDate dateOfBirth;

	  
	    private LocalDate date;

	   
	    private String place;

	    
	    private Integer patientId;


	    private Long phoneNo;

	   
	    private PrivateDetails privateDetails;

	    
	    private List<FamilyRelationShipModel> familyRelationShips = new ArrayList<>();

	   
	    private List<InsurarModel> insurars = new ArrayList<>();

	    
	    private List<BookingModel> bookings = new ArrayList<>();

	    private CountryModel country;
	    private GenderModel gender;


		public Long getId() {
			return id;
		}


		public void setId(Long id) {
			this.id = id;
		}


		public String getFirstName() {
			return firstName;
		}


		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}


		public String getLastName() {
			return lastName;
		}


		public void setLastName(String lastName) {
			this.lastName = lastName;
		}


		public LocalDate getDateOfBirth() {
			return dateOfBirth;
		}


		public void setDateOfBirth(LocalDate dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}


		public LocalDate getDate() {
			return date;
		}


		public void setDate(LocalDate date) {
			this.date = date;
		}


		public String getPlace() {
			return place;
		}


		public void setPlace(String place) {
			this.place = place;
		}


		public Integer getPatientId() {
			return patientId;
		}


		public void setPatientId(Integer patientId) {
			this.patientId = patientId;
		}


		public Long getPhoneNo() {
			return phoneNo;
		}


		public void setPhoneNo(Long phoneNo) {
			this.phoneNo = phoneNo;
		}


		public PrivateDetails getPrivateDetails() {
			return privateDetails;
		}


		public void setPrivateDetails(PrivateDetails privateDetails) {
			this.privateDetails = privateDetails;
		}


		public List<FamilyRelationShipModel> getFamilyRelationShips() {
			return familyRelationShips;
		}


		public void setFamilyRelationShips(List<FamilyRelationShipModel> familyRelationShips) {
			this.familyRelationShips = familyRelationShips;
		}


		public List<InsurarModel> getInsurars() {
			return insurars;
		}


		public void setInsurars(List<InsurarModel> insurars) {
			this.insurars = insurars;
		}


		public List<BookingModel> getBookings() {
			return bookings;
		}


		public void setBookings(List<BookingModel> bookings) {
			this.bookings = bookings;
		}


		public CountryModel getCountry() {
			return country;
		}


		public void setCountry(CountryModel country) {
			this.country = country;
		}


		public GenderModel getGender() {
			return gender;
		}


		public void setGender(GenderModel gender) {
			this.gender = gender;
		}


	
}
