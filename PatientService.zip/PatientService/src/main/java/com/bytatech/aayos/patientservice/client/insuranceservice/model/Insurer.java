package com.bytatech.aayos.patientservice.client.insuranceservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Insurer
 */
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2018-03-14T11:48:59.500+05:30")

public class Insurer   {
  @JsonProperty("address")
  private String address = null;

  @JsonProperty("contactNumber")
  private Long contactNumber = null;

  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("insurarName")
  private String insurarName = null;

  public Insurer address(String address) {
    this.address = address;
    return this;
  }

   /**
   * Get address
   * @return address
  **/
  @ApiModelProperty(value = "")
  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public Insurer contactNumber(Long contactNumber) {
    this.contactNumber = contactNumber;
    return this;
  }

   /**
   * Get contactNumber
   * @return contactNumber
  **/
  @ApiModelProperty(value = "")
  public Long getContactNumber() {
    return contactNumber;
  }

  public void setContactNumber(Long contactNumber) {
    this.contactNumber = contactNumber;
  }

  public Insurer id(Long id) {
    this.id = id;
    return this;
  }

   /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(value = "")
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Insurer insurarName(String insurarName) {
    this.insurarName = insurarName;
    return this;
  }

   /**
   * Get insurarName
   * @return insurarName
  **/
  @ApiModelProperty(value = "")
  public String getInsurarName() {
    return insurarName;
  }

  public void setInsurarName(String insurarName) {
    this.insurarName = insurarName;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Insurer insurer = (Insurer) o;
    return Objects.equals(this.address, insurer.address) &&
        Objects.equals(this.contactNumber, insurer.contactNumber) &&
        Objects.equals(this.id, insurer.id) &&
        Objects.equals(this.insurarName, insurer.insurarName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(address, contactNumber, id, insurarName);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Insurer {\n");
    
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    contactNumber: ").append(toIndentedString(contactNumber)).append("\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    insurarName: ").append(toIndentedString(insurarName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

