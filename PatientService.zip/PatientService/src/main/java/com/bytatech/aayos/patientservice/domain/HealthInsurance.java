package com.bytatech.aayos.patientservice.domain;

import io.swagger.annotations.ApiModel;

import javax.persistence.*;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

/**
 * The HealthInsurance entity.
 * @author MayaSanjeev.
 */
@ApiModel(description = "The HealthInsurance entity. @author MayaSanjeev.")
@Entity
@Table(name = "health_insurance")
public class HealthInsurance implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "insurance_number")
    private Long insuranceNumber;

    @Column(name = "expirary_date")
    private LocalDate expiraryDate;

    @ManyToOne
    private Insurar insurar;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getInsuranceNumber() {
        return insuranceNumber;
    }

    public HealthInsurance insuranceNumber(Long insuranceNumber) {
        this.insuranceNumber = insuranceNumber;
        return this;
    }

    public void setInsuranceNumber(Long insuranceNumber) {
        this.insuranceNumber = insuranceNumber;
    }

    public LocalDate getExpiraryDate() {
        return expiraryDate;
    }

    public HealthInsurance expiraryDate(LocalDate expiraryDate) {
        this.expiraryDate = expiraryDate;
        return this;
    }

    public void setExpiraryDate(LocalDate expiraryDate) {
        this.expiraryDate = expiraryDate;
    }

    public Insurar getInsurar() {
        return insurar;
    }

    public HealthInsurance insurar(Insurar insurar) {
        this.insurar = insurar;
        return this;
    }

    public void setInsurar(Insurar insurar) {
        this.insurar = insurar;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        HealthInsurance healthInsurance = (HealthInsurance) o;
        if (healthInsurance.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), healthInsurance.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "HealthInsurance{" +
            "id=" + getId() +
            ", insuranceNumber=" + getInsuranceNumber() +
            ", expiraryDate='" + getExpiraryDate() + "'" +
            "}";
    }
}
