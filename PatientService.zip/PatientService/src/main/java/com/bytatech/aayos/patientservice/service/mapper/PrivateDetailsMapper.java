package com.bytatech.aayos.patientservice.service.mapper;

import com.bytatech.aayos.patientservice.domain.*;
import com.bytatech.aayos.patientservice.service.dto.PrivateDetailsDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity PrivateDetails and its DTO PrivateDetailsDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface PrivateDetailsMapper extends EntityMapper<PrivateDetailsDTO, PrivateDetails> {

    

    

    default PrivateDetails fromId(Long id) {
        if (id == null) {
            return null;
        }
        PrivateDetails privateDetails = new PrivateDetails();
        privateDetails.setId(id);
        return privateDetails;
    }
}
