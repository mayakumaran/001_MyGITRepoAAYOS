package com.bytatech.aayos.patientservice.domain;

import io.swagger.annotations.ApiModel;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Objects;

/**
 * The PrivateDetails entity.
 * @author MayaSanjeev.
 */
@ApiModel(description = "The PrivateDetails entity. @author MayaSanjeev.")
@Entity
@Table(name = "private_details")
public class PrivateDetails implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "email")
    private String email;

    @Column(name = "address")
    private String address;

    @Column(name = "town")
    private String town;

    @Column(name = "zip_code")
    private Integer zipCode;

    @Column(name = "social_media")
    private String socialMedia;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public PrivateDetails email(String email) {
        this.email = email;
        return this;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public PrivateDetails address(String address) {
        this.address = address;
        return this;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTown() {
        return town;
    }

    public PrivateDetails town(String town) {
        this.town = town;
        return this;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public Integer getZipCode() {
        return zipCode;
    }

    public PrivateDetails zipCode(Integer zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    public void setZipCode(Integer zipCode) {
        this.zipCode = zipCode;
    }

    public String getSocialMedia() {
        return socialMedia;
    }

    public PrivateDetails socialMedia(String socialMedia) {
        this.socialMedia = socialMedia;
        return this;
    }

    public void setSocialMedia(String socialMedia) {
        this.socialMedia = socialMedia;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PrivateDetails privateDetails = (PrivateDetails) o;
        if (privateDetails.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), privateDetails.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "PrivateDetails{" +
            "id=" + getId() +
            ", email='" + getEmail() + "'" +
            ", address='" + getAddress() + "'" +
            ", town='" + getTown() + "'" +
            ", zipCode=" + getZipCode() +
            ", socialMedia='" + getSocialMedia() + "'" +
            "}";
    }
}
