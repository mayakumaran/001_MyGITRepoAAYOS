package com.bytatech.aayos.patientservice.config;

import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableFeignClients(basePackages = "com.bytatech.aayos.patientservice")
public class FeignConfiguration {

}
