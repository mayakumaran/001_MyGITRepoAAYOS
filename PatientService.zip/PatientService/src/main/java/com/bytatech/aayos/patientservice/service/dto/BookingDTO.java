package com.bytatech.aayos.patientservice.service.dto;


import java.time.Instant;
import java.time.LocalDate;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A DTO for the Booking entity.
 */
public class BookingDTO implements Serializable {

    private Long id;

    private Long bookingId;

    private String doctorName;

    private Instant estimateTime;

    private LocalDate date;

    private Integer tokenNumber;

    private LocalDate dateOfBooking;

    private Instant timeOfBooking;

    private Long admissionNo;

    private Long patientId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public Instant getEstimateTime() {
        return estimateTime;
    }

    public void setEstimateTime(Instant estimateTime) {
        this.estimateTime = estimateTime;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Integer getTokenNumber() {
        return tokenNumber;
    }

    public void setTokenNumber(Integer tokenNumber) {
        this.tokenNumber = tokenNumber;
    }

    public LocalDate getDateOfBooking() {
        return dateOfBooking;
    }

    public void setDateOfBooking(LocalDate dateOfBooking) {
        this.dateOfBooking = dateOfBooking;
    }

    public Instant getTimeOfBooking() {
        return timeOfBooking;
    }

    public void setTimeOfBooking(Instant timeOfBooking) {
        this.timeOfBooking = timeOfBooking;
    }

    public Long getAdmissionNo() {
        return admissionNo;
    }

    public void setAdmissionNo(Long admissionNo) {
        this.admissionNo = admissionNo;
    }

    public Long getPatientId() {
        return patientId;
    }

    public void setPatientId(Long patientId) {
        this.patientId = patientId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        BookingDTO bookingDTO = (BookingDTO) o;
        if(bookingDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), bookingDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "BookingDTO{" +
            "id=" + getId() +
            ", bookingId=" + getBookingId() +
            ", doctorName='" + getDoctorName() + "'" +
            ", estimateTime='" + getEstimateTime() + "'" +
            ", date='" + getDate() + "'" +
            ", tokenNumber=" + getTokenNumber() +
            ", dateOfBooking='" + getDateOfBooking() + "'" +
            ", timeOfBooking='" + getTimeOfBooking() + "'" +
            ", admissionNo=" + getAdmissionNo() +
            "}";
    }
}
