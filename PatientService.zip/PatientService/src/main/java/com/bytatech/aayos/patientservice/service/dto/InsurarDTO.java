package com.bytatech.aayos.patientservice.service.dto;


import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A DTO for the Insurar entity.
 */
public class InsurarDTO implements Serializable {

  

	private Long id;

    private String insurarName;

    private Long patientId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getInsurarName() {
        return insurarName;
    }

    public void setInsurarName(String insurarName) {
        this.insurarName = insurarName;
    }

    public Long getPatientId() {
        return patientId;
    }

    public void setPatientId(Long patientId) {
        this.patientId = patientId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InsurarDTO insurarDTO = (InsurarDTO) o;
        if(insurarDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), insurarDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InsurarDTO{" +
            "id=" + getId() +
            ", insurarName='" + getInsurarName() + "'" +
            "}";
    }
}
