package com.bytatech.aayos.patientservice.client.insuranceservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;

/**
 * HealthInsuranceDTO
 */
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2018-03-14T11:48:59.500+05:30")

public class HealthInsuranceDTO   {
  @JsonProperty("categoryId")
  private Long categoryId = null;

  @JsonProperty("coverager")
  private String coverager = null;

  @JsonProperty("createdDate")
  private LocalDate createdDate = null;

  @JsonProperty("expiryDate")
  private LocalDate expiryDate = null;

  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("insuranceNumber")
  private Long insuranceNumber = null;

  @JsonProperty("insurerId")
  private Long insurerId = null;

  @JsonProperty("patientId")
  private Long patientId = null;

  @JsonProperty("statusId")
  private Long statusId = null;


/**
 * @param expiraryDate
 * @param insuranceNumber
 * @param insurarId
 * @param patientId2
 */
public HealthInsuranceDTO(LocalDate expiraryDate, Long insuranceNumber, Long insurarId, Long patientId) {
this.expiryDate=expiraryDate;
this.insuranceNumber=insuranceNumber;
this.insurerId=insurarId;
this.patientId=patientId;
}

public HealthInsuranceDTO categoryId(Long categoryId) {
    this.categoryId = categoryId;
    return this;
  }

   /**
   * Get categoryId
   * @return categoryId
  **/
  @ApiModelProperty(value = "")
  public Long getCategoryId() {
    return categoryId;
  }

  public void setCategoryId(Long categoryId) {
    this.categoryId = categoryId;
  }

  public HealthInsuranceDTO coverager(String coverager) {
    this.coverager = coverager;
    return this;
  }

   /**
   * Get coverager
   * @return coverager
  **/
  @ApiModelProperty(value = "")
  public String getCoverager() {
    return coverager;
  }

  public void setCoverager(String coverager) {
    this.coverager = coverager;
  }

  public HealthInsuranceDTO createdDate(LocalDate createdDate) {
    this.createdDate = createdDate;
    return this;
  }

   /**
   * Get createdDate
   * @return createdDate
  **/
  @ApiModelProperty(value = "")
  public LocalDate getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(LocalDate createdDate) {
    this.createdDate = createdDate;
  }

  public HealthInsuranceDTO expiryDate(LocalDate expiryDate) {
    this.expiryDate = expiryDate;
    return this;
  }

   /**
   * Get expiryDate
   * @return expiryDate
  **/
  @ApiModelProperty(value = "")
  public LocalDate getExpiryDate() {
    return expiryDate;
  }

  public void setExpiryDate(LocalDate expiryDate) {
    this.expiryDate = expiryDate;
  }

  public HealthInsuranceDTO id(Long id) {
    this.id = id;
    return this;
  }

   /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(value = "")
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public HealthInsuranceDTO insuranceNumber(Long insuranceNumber) {
    this.insuranceNumber = insuranceNumber;
    return this;
  }

   /**
   * Get insuranceNumber
   * @return insuranceNumber
  **/
  @ApiModelProperty(value = "")
  public Long getInsuranceNumber() {
    return insuranceNumber;
  }

  public void setInsuranceNumber(Long insuranceNumber) {
    this.insuranceNumber = insuranceNumber;
  }

  public HealthInsuranceDTO insurerId(Long insurerId) {
    this.insurerId = insurerId;
    return this;
  }

   /**
   * Get insurerId
   * @return insurerId
  **/
  @ApiModelProperty(value = "")
  public Long getInsurerId() {
    return insurerId;
  }

  public void setInsurerId(Long insurerId) {
    this.insurerId = insurerId;
  }

  public HealthInsuranceDTO patientId(Long patientId) {
    this.patientId = patientId;
    return this;
  }

   /**
   * Get patientId
   * @return patientId
  **/
  @ApiModelProperty(value = "")
  public Long getPatientId() {
    return patientId;
  }

  public void setPatientId(Long patientId) {
    this.patientId = patientId;
  }

  public HealthInsuranceDTO statusId(Long statusId) {
    this.statusId = statusId;
    return this;
  }

   /**
   * Get statusId
   * @return statusId
  **/
  @ApiModelProperty(value = "")
  public Long getStatusId() {
    return statusId;
  }

  public void setStatusId(Long statusId) {
    this.statusId = statusId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HealthInsuranceDTO healthInsuranceDTO = (HealthInsuranceDTO) o;
    return Objects.equals(this.categoryId, healthInsuranceDTO.categoryId) &&
        Objects.equals(this.coverager, healthInsuranceDTO.coverager) &&
        Objects.equals(this.createdDate, healthInsuranceDTO.createdDate) &&
        Objects.equals(this.expiryDate, healthInsuranceDTO.expiryDate) &&
        Objects.equals(this.id, healthInsuranceDTO.id) &&
        Objects.equals(this.insuranceNumber, healthInsuranceDTO.insuranceNumber) &&
        Objects.equals(this.insurerId, healthInsuranceDTO.insurerId) &&
        Objects.equals(this.patientId, healthInsuranceDTO.patientId) &&
        Objects.equals(this.statusId, healthInsuranceDTO.statusId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(categoryId, coverager, createdDate, expiryDate, id, insuranceNumber, insurerId, patientId, statusId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HealthInsuranceDTO {\n");
    
    sb.append("    categoryId: ").append(toIndentedString(categoryId)).append("\n");
    sb.append("    coverager: ").append(toIndentedString(coverager)).append("\n");
    sb.append("    createdDate: ").append(toIndentedString(createdDate)).append("\n");
    sb.append("    expiryDate: ").append(toIndentedString(expiryDate)).append("\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    insuranceNumber: ").append(toIndentedString(insuranceNumber)).append("\n");
    sb.append("    insurerId: ").append(toIndentedString(insurerId)).append("\n");
    sb.append("    patientId: ").append(toIndentedString(patientId)).append("\n");
    sb.append("    statusId: ").append(toIndentedString(statusId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

