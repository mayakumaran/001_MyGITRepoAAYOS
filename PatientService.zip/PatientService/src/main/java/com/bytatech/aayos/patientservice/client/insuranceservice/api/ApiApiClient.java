package com.bytatech.aayos.patientservice.client.insuranceservice.api;

import org.springframework.cloud.netflix.feign.FeignClient;
import com.bytatech.aayos.patientservice.client.insuranceservice.ClientConfiguration;

@FeignClient(name="${insuranceservice.name:insuranceservice}", url="${insuranceservice.url:https://192.168.43.116:8081}", configuration = ClientConfiguration.class)
public interface ApiApiClient extends ApiApi {
}