package com.bytatech.aayos.patientservice.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;

import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * The Patient entity.
 * @author MayaSanjeev.
 */
@ApiModel(description = "The Patient entity. @author MayaSanjeev.")
@Entity
@Table(name = "patient")
public class Patient implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Size(max = 45)
    @Column(name = "first_name", length = 45, nullable = false)
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "date_of_birth")
    private LocalDate dateOfBirth;

    @Column(name = "jhi_date")
    private LocalDate date;

    @Column(name = "place")
    private String place;

    @Column(name = "patient_id")
    private Integer patientId;

    @NotNull
    @Column(name = "phone_no", nullable = false)
    private Long phoneNo;

    @OneToOne
    @JoinColumn(unique = true)
    private PrivateDetails privateDetails;

    @OneToMany(mappedBy = "patient")
    @JsonIgnore
    private Set<FamilyRelationShip> familyRelationShips = new HashSet<>();

    @OneToMany(mappedBy = "patient")
    @JsonIgnore
    private Set<Insurar> insurars = new HashSet<>();

    @OneToMany(mappedBy = "patient")
    @JsonIgnore
    private Set<Booking> bookings = new HashSet<>();

    @ManyToOne
    private Country country;

    @ManyToOne
    private Gender gender;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public Patient firstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public Patient lastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public Patient dateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public LocalDate getDate() {
        return date;
    }

    public Patient date(LocalDate date) {
        this.date = date;
        return this;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getPlace() {
        return place;
    }

    public Patient place(String place) {
        this.place = place;
        return this;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public Integer getPatientId() {
        return patientId;
    }

    public Patient patientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public Long getPhoneNo() {
        return phoneNo;
    }

    public Patient phoneNo(Long phoneNo) {
        this.phoneNo = phoneNo;
        return this;
    }

    public void setPhoneNo(Long phoneNo) {
        this.phoneNo = phoneNo;
    }

    public PrivateDetails getPrivateDetails() {
        return privateDetails;
    }

    public Patient privateDetails(PrivateDetails privateDetails) {
        this.privateDetails = privateDetails;
        return this;
    }

    public void setPrivateDetails(PrivateDetails privateDetails) {
        this.privateDetails = privateDetails;
    }

    public Set<FamilyRelationShip> getFamilyRelationShips() {
        return familyRelationShips;
    }

    public Patient familyRelationShips(Set<FamilyRelationShip> familyRelationShips) {
        this.familyRelationShips = familyRelationShips;
        return this;
    }

    public Patient addFamilyRelationShip(FamilyRelationShip familyRelationShip) {
        this.familyRelationShips.add(familyRelationShip);
        familyRelationShip.setPatient(this);
        return this;
    }

    public Patient removeFamilyRelationShip(FamilyRelationShip familyRelationShip) {
        this.familyRelationShips.remove(familyRelationShip);
        familyRelationShip.setPatient(null);
        return this;
    }

    public void setFamilyRelationShips(Set<FamilyRelationShip> familyRelationShips) {
        this.familyRelationShips = familyRelationShips;
    }

    public Set<Insurar> getInsurars() {
        return insurars;
    }

    public Patient insurars(Set<Insurar> insurars) {
        this.insurars = insurars;
        return this;
    }

    public Patient addInsurar(Insurar insurar) {
        this.insurars.add(insurar);
        insurar.setPatient(this);
        return this;
    }

    public Patient removeInsurar(Insurar insurar) {
        this.insurars.remove(insurar);
        insurar.setPatient(null);
        return this;
    }

    public void setInsurars(Set<Insurar> insurars) {
        this.insurars = insurars;
    }

    public Set<Booking> getBookings() {
        return bookings;
    }

    public Patient bookings(Set<Booking> bookings) {
        this.bookings = bookings;
        return this;
    }

    public Patient addBooking(Booking booking) {
        this.bookings.add(booking);
        booking.setPatient(this);
        return this;
    }

    public Patient removeBooking(Booking booking) {
        this.bookings.remove(booking);
        booking.setPatient(null);
        return this;
    }

    public void setBookings(Set<Booking> bookings) {
        this.bookings = bookings;
    }

    public Country getCountry() {
        return country;
    }

    public Patient country(Country country) {
        this.country = country;
        return this;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public Gender getGender() {
        return gender;
    }

    public Patient gender(Gender gender) {
        this.gender = gender;
        return this;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Patient patient = (Patient) o;
        if (patient.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), patient.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Patient{" +
            "id=" + getId() +
            ", firstName='" + getFirstName() + "'" +
            ", lastName='" + getLastName() + "'" +
            ", dateOfBirth='" + getDateOfBirth() + "'" +
            ", date='" + getDate() + "'" +
            ", place='" + getPlace() + "'" +
            ", patientId=" + getPatientId() +
            ", phoneNo=" + getPhoneNo() +
            "}";
    }
}
