package com.bytatech.aayos.patientservice.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;

import javax.persistence.*;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * The Insurar entity.
 * @author MayaSanjeev.
 */
@ApiModel(description = "The Insurar entity. @author MayaSanjeev.")
@Entity
@Table(name = "insurar")
public class Insurar implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "insurar_name")
    private String insurarName;

    @ManyToOne
    private Patient patient;

    @OneToMany(mappedBy = "insurar")
    @JsonIgnore
    private Set<HealthInsurance> healthInsurances = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getInsurarName() {
        return insurarName;
    }

    public Insurar insurarName(String insurarName) {
        this.insurarName = insurarName;
        return this;
    }

    public void setInsurarName(String insurarName) {
        this.insurarName = insurarName;
    }

    public Patient getPatient() {
        return patient;
    }

    public Insurar patient(Patient patient) {
        this.patient = patient;
        return this;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Set<HealthInsurance> getHealthInsurances() {
        return healthInsurances;
    }

    public Insurar healthInsurances(Set<HealthInsurance> healthInsurances) {
        this.healthInsurances = healthInsurances;
        return this;
    }

    public Insurar addHealthInsurance(HealthInsurance healthInsurance) {
        this.healthInsurances.add(healthInsurance);
        healthInsurance.setInsurar(this);
        return this;
    }

    public Insurar removeHealthInsurance(HealthInsurance healthInsurance) {
        this.healthInsurances.remove(healthInsurance);
        healthInsurance.setInsurar(null);
        return this;
    }

    public void setHealthInsurances(Set<HealthInsurance> healthInsurances) {
        this.healthInsurances = healthInsurances;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Insurar insurar = (Insurar) o;
        if (insurar.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), insurar.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Insurar{" +
            "id=" + getId() +
            ", insurarName='" + getInsurarName() + "'" +
            "}";
    }
}
