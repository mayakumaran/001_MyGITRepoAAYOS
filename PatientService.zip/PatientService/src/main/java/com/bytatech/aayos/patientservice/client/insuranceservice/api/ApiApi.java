package com.bytatech.aayos.patientservice.client.insuranceservice.api;

import com.bytatech.aayos.patientservice.client.insuranceservice.model.CoveredActivityDTO;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.DepartmentDTO;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.HealthInsuranceDTO;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.InsuranceCategoryDTO;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.InsurerInvoiceStatusDTO;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.InsurerInvoiceDTO;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.InsurerDTO;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.RelationshipDTO;
import java.time.LocalDate;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.CoveredActivity;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.User;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.ProfileInfoVM;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.HealthInsurance;

import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2018-03-14T11:48:59.500+05:30")

@Api(value = "api", description = "the api API")
public interface ApiApi {

    @ApiOperation(value = "createCoveredActivity", notes = "", response = CoveredActivityDTO.class, tags={ "covered-activity-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = CoveredActivityDTO.class),
        @ApiResponse(code = 201, message = "Created", response = CoveredActivityDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = CoveredActivityDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = CoveredActivityDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = CoveredActivityDTO.class) })
    @RequestMapping(value = "/api/covered-activities",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.POST)
    ResponseEntity<CoveredActivityDTO> createCoveredActivityUsingPOST(@ApiParam(value = "coveredActivityDTO" ,required=true ) @RequestBody CoveredActivityDTO coveredActivityDTO);


    @ApiOperation(value = "createDepartment", notes = "", response = DepartmentDTO.class, tags={ "department-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = DepartmentDTO.class),
        @ApiResponse(code = 201, message = "Created", response = DepartmentDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = DepartmentDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = DepartmentDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = DepartmentDTO.class) })
    @RequestMapping(value = "/api/departments",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.POST)
    ResponseEntity<DepartmentDTO> createDepartmentUsingPOST(@ApiParam(value = "departmentDTO" ,required=true ) @RequestBody DepartmentDTO departmentDTO);


    @ApiOperation(value = "createHealthInsurance", notes = "", response = HealthInsuranceDTO.class, tags={ "health-insurance-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 201, message = "Created", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = HealthInsuranceDTO.class) })
    @RequestMapping(value = "/api/health-insurances",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.POST)
    ResponseEntity<HealthInsuranceDTO> createHealthInsuranceUsingPOST(@ApiParam(value = "healthInsuranceDTO" ,required=true ) @RequestBody HealthInsuranceDTO healthInsuranceDTO);


    @ApiOperation(value = "createInsuranceCategory", notes = "", response = InsuranceCategoryDTO.class, tags={ "insurance-category-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 201, message = "Created", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsuranceCategoryDTO.class) })
    @RequestMapping(value = "/api/insurance-categories",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.POST)
    ResponseEntity<InsuranceCategoryDTO> createInsuranceCategoryUsingPOST(@ApiParam(value = "insuranceCategoryDTO" ,required=true ) @RequestBody InsuranceCategoryDTO insuranceCategoryDTO);


    @ApiOperation(value = "createInsurerInvoiceStatus", notes = "", response = InsurerInvoiceStatusDTO.class, tags={ "insurer-invoice-status-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 201, message = "Created", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerInvoiceStatusDTO.class) })
    @RequestMapping(value = "/api/insurer-invoice-statuses",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.POST)
    ResponseEntity<InsurerInvoiceStatusDTO> createInsurerInvoiceStatusUsingPOST(@ApiParam(value = "insurerInvoiceStatusDTO" ,required=true ) @RequestBody InsurerInvoiceStatusDTO insurerInvoiceStatusDTO);


    @ApiOperation(value = "createInsurerInvoice", notes = "", response = InsurerInvoiceDTO.class, tags={ "insurer-invoice-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 201, message = "Created", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerInvoiceDTO.class) })
    @RequestMapping(value = "/api/insurer-invoices",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.POST)
    ResponseEntity<InsurerInvoiceDTO> createInsurerInvoiceUsingPOST(@ApiParam(value = "insurerInvoiceDTO" ,required=true ) @RequestBody InsurerInvoiceDTO insurerInvoiceDTO);


    @ApiOperation(value = "createInsurer", notes = "", response = InsurerDTO.class, tags={ "insurer-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerDTO.class),
        @ApiResponse(code = 201, message = "Created", response = InsurerDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerDTO.class) })
    @RequestMapping(value = "/api/insurers",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.POST)
    ResponseEntity<InsurerDTO> createInsurerUsingPOST(@ApiParam(value = "insurerDTO" ,required=true ) @RequestBody InsurerDTO insurerDTO);


    @ApiOperation(value = "createRelationship", notes = "", response = RelationshipDTO.class, tags={ "relationship-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = RelationshipDTO.class),
        @ApiResponse(code = 201, message = "Created", response = RelationshipDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = RelationshipDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = RelationshipDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = RelationshipDTO.class) })
    @RequestMapping(value = "/api/relationships",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.POST)
    ResponseEntity<RelationshipDTO> createRelationshipUsingPOST(@ApiParam(value = "relationshipDTO" ,required=true ) @RequestBody RelationshipDTO relationshipDTO);


    @ApiOperation(value = "deleteCoveredActivity", notes = "", response = Void.class, tags={ "covered-activity-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = Void.class),
        @ApiResponse(code = 204, message = "No Content", response = Void.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Void.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Void.class) })
    @RequestMapping(value = "/api/covered-activities/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.DELETE)
    ResponseEntity<Void> deleteCoveredActivityUsingDELETE(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "deleteDepartment", notes = "", response = Void.class, tags={ "department-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = Void.class),
        @ApiResponse(code = 204, message = "No Content", response = Void.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Void.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Void.class) })
    @RequestMapping(value = "/api/departments/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.DELETE)
    ResponseEntity<Void> deleteDepartmentUsingDELETE(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "deleteHealthInsurance", notes = "", response = Void.class, tags={ "health-insurance-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = Void.class),
        @ApiResponse(code = 204, message = "No Content", response = Void.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Void.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Void.class) })
    @RequestMapping(value = "/api/health-insurances/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.DELETE)
    ResponseEntity<Void> deleteHealthInsuranceUsingDELETE(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "deleteInsuranceCategory", notes = "", response = Void.class, tags={ "insurance-category-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = Void.class),
        @ApiResponse(code = 204, message = "No Content", response = Void.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Void.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Void.class) })
    @RequestMapping(value = "/api/insurance-categories/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.DELETE)
    ResponseEntity<Void> deleteInsuranceCategoryUsingDELETE(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "deleteInsurerInvoiceStatus", notes = "", response = Void.class, tags={ "insurer-invoice-status-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = Void.class),
        @ApiResponse(code = 204, message = "No Content", response = Void.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Void.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Void.class) })
    @RequestMapping(value = "/api/insurer-invoice-statuses/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.DELETE)
    ResponseEntity<Void> deleteInsurerInvoiceStatusUsingDELETE(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "deleteInsurerInvoice", notes = "", response = Void.class, tags={ "insurer-invoice-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = Void.class),
        @ApiResponse(code = 204, message = "No Content", response = Void.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Void.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Void.class) })
    @RequestMapping(value = "/api/insurer-invoices/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.DELETE)
    ResponseEntity<Void> deleteInsurerInvoiceUsingDELETE(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "deleteInsurer", notes = "", response = Void.class, tags={ "insurer-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = Void.class),
        @ApiResponse(code = 204, message = "No Content", response = Void.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Void.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Void.class) })
    @RequestMapping(value = "/api/insurers/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.DELETE)
    ResponseEntity<Void> deleteInsurerUsingDELETE(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "deleteRelationship", notes = "", response = Void.class, tags={ "relationship-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = Void.class),
        @ApiResponse(code = 204, message = "No Content", response = Void.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Void.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Void.class) })
    @RequestMapping(value = "/api/relationships/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.DELETE)
    ResponseEntity<Void> deleteRelationshipUsingDELETE(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "findByCreatedDateBetween", notes = "", response = HealthInsuranceDTO.class, responseContainer = "List", tags={ "health-insurance-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = HealthInsuranceDTO.class) })
    @RequestMapping(value = "/api/health-insurances/	",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<HealthInsuranceDTO>> findByCreatedDateBetweenUsingGET(@ApiParam(value = "startDate", required = true) @RequestParam(value = "startDate", required = true) LocalDate startDate,
        @ApiParam(value = "endDate", required = true) @RequestParam(value = "endDate", required = true) LocalDate endDate);


    @ApiOperation(value = "findByInsuranceNumber", notes = "", response = HealthInsuranceDTO.class, tags={ "health-insurance-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = HealthInsuranceDTO.class) })
    @RequestMapping(value = "/api/health-insurances/findByInsuranceNumber",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<HealthInsuranceDTO> findByInsuranceNumberUsingGET(@ApiParam(value = "insuranceNumber") @RequestParam(value = "insuranceNumber", required = false) Long insuranceNumber);


    @ApiOperation(value = "findByInsurer", notes = "", response = HealthInsuranceDTO.class, responseContainer = "List", tags={ "health-insurance-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = HealthInsuranceDTO.class) })
    @RequestMapping(value = "/api/health-insurances/findByInsurer",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<HealthInsuranceDTO>> findByInsurerUsingGET(@ApiParam(value = "insurerId") @RequestParam(value = "insurerId", required = false) Long insurerId);


    @ApiOperation(value = "findByPatientId", notes = "", response = HealthInsuranceDTO.class, tags={ "health-insurance-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = HealthInsuranceDTO.class) })
    @RequestMapping(value = "/api/health-insurances/findByPatientId",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<HealthInsuranceDTO> findByPatientIdUsingGET(@ApiParam(value = "patientId") @RequestParam(value = "patientId", required = false) Long patientId);


    @ApiOperation(value = "findCoveredActivitiesByInsuranceNumber", notes = "", response = CoveredActivity.class, responseContainer = "List", tags={ "health-insurance-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = CoveredActivity.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = CoveredActivity.class),
        @ApiResponse(code = 403, message = "Forbidden", response = CoveredActivity.class),
        @ApiResponse(code = 404, message = "Not Found", response = CoveredActivity.class) })
    @RequestMapping(value = "/api/health-insurance-marshaled",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<CoveredActivity>> findCoveredActivitiesByInsuranceNumberUsingGET(@ApiParam(value = "patientId") @RequestParam(value = "patientId", required = false) Long patientId);


    @ApiOperation(value = "getAccount", notes = "", response = User.class, tags={ "account-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = User.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = User.class),
        @ApiResponse(code = 403, message = "Forbidden", response = User.class),
        @ApiResponse(code = 404, message = "Not Found", response = User.class) })
    @RequestMapping(value = "/api/account",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<User> getAccountUsingGET();


    @ApiOperation(value = "getActiveProfiles", notes = "", response = ProfileInfoVM.class, tags={ "profile-info-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = ProfileInfoVM.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = ProfileInfoVM.class),
        @ApiResponse(code = 403, message = "Forbidden", response = ProfileInfoVM.class),
        @ApiResponse(code = 404, message = "Not Found", response = ProfileInfoVM.class) })
    @RequestMapping(value = "/api/profile-info",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<ProfileInfoVM> getActiveProfilesUsingGET();


    @ApiOperation(value = "getAllByInsurerInvoiceDate", notes = "", response = InsurerInvoiceDTO.class, responseContainer = "List", tags={ "insurer-invoice-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerInvoiceDTO.class) })
    @RequestMapping(value = "/api/insurer-invoices/findByInvoiceDate/{invoiceDate}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<InsurerInvoiceDTO>> getAllByInsurerInvoiceDateUsingGET(@ApiParam(value = "invoiceDate",required=true ) @PathVariable("invoiceDate") LocalDate invoiceDate);


    @ApiOperation(value = "getAllCoveredActivities", notes = "", response = CoveredActivityDTO.class, responseContainer = "List", tags={ "covered-activity-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = CoveredActivityDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = CoveredActivityDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = CoveredActivityDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = CoveredActivityDTO.class) })
    @RequestMapping(value = "/api/covered-activities",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<CoveredActivityDTO>> getAllCoveredActivitiesUsingGET(@ApiParam(value = "Page number of the requested page") @RequestParam(value = "page", required = false) Integer page,
        @ApiParam(value = "Size of a page") @RequestParam(value = "size", required = false) Integer size,
        @ApiParam(value = "Sorting criteria in the format: property(,asc|desc). Default sort order is ascending. Multiple sort criteria are supported.") @RequestParam(value = "sort", required = false) List<String> sort);


    @ApiOperation(value = "getAllDepartments", notes = "", response = DepartmentDTO.class, responseContainer = "List", tags={ "department-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = DepartmentDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = DepartmentDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = DepartmentDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = DepartmentDTO.class) })
    @RequestMapping(value = "/api/departments",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<DepartmentDTO>> getAllDepartmentsUsingGET(@ApiParam(value = "Page number of the requested page") @RequestParam(value = "page", required = false) Integer page,
        @ApiParam(value = "Size of a page") @RequestParam(value = "size", required = false) Integer size,
        @ApiParam(value = "Sorting criteria in the format: property(,asc|desc). Default sort order is ascending. Multiple sort criteria are supported.") @RequestParam(value = "sort", required = false) List<String> sort);


    @ApiOperation(value = "getAllHealthInsurances", notes = "", response = HealthInsuranceDTO.class, responseContainer = "List", tags={ "health-insurance-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = HealthInsuranceDTO.class) })
    @RequestMapping(value = "/api/health-insurances",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<HealthInsuranceDTO>> getAllHealthInsurancesUsingGET(@ApiParam(value = "Page number of the requested page") @RequestParam(value = "page", required = false) Integer page,
        @ApiParam(value = "Size of a page") @RequestParam(value = "size", required = false) Integer size,
        @ApiParam(value = "Sorting criteria in the format: property(,asc|desc). Default sort order is ascending. Multiple sort criteria are supported.") @RequestParam(value = "sort", required = false) List<String> sort);


    @ApiOperation(value = "getAllInsuranceCategories", notes = "", response = InsuranceCategoryDTO.class, responseContainer = "List", tags={ "insurance-category-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsuranceCategoryDTO.class) })
    @RequestMapping(value = "/api/insurance-categories",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<InsuranceCategoryDTO>> getAllInsuranceCategoriesUsingGET(@ApiParam(value = "Page number of the requested page") @RequestParam(value = "page", required = false) Integer page,
        @ApiParam(value = "Size of a page") @RequestParam(value = "size", required = false) Integer size,
        @ApiParam(value = "Sorting criteria in the format: property(,asc|desc). Default sort order is ascending. Multiple sort criteria are supported.") @RequestParam(value = "sort", required = false) List<String> sort);


    @ApiOperation(value = "getAllInsurerInvoiceStatus", notes = "", response = InsurerInvoiceDTO.class, responseContainer = "List", tags={ "insurer-invoice-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerInvoiceDTO.class) })
    @RequestMapping(value = "/api/insurer-invoices/findByInsurerInvoiceStatus/{insurerInvoiceStatus}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<InsurerInvoiceDTO>> getAllInsurerInvoiceStatusUsingGET(@ApiParam(value = "insurerInvoiceStatus",required=true ) @PathVariable("insurerInvoiceStatus") String insurerInvoiceStatus);


    @ApiOperation(value = "getAllInsurerInvoiceStatuses", notes = "", response = InsurerInvoiceStatusDTO.class, responseContainer = "List", tags={ "insurer-invoice-status-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerInvoiceStatusDTO.class) })
    @RequestMapping(value = "/api/insurer-invoice-statuses",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<InsurerInvoiceStatusDTO>> getAllInsurerInvoiceStatusesUsingGET(@ApiParam(value = "Page number of the requested page") @RequestParam(value = "page", required = false) Integer page,
        @ApiParam(value = "Size of a page") @RequestParam(value = "size", required = false) Integer size,
        @ApiParam(value = "Sorting criteria in the format: property(,asc|desc). Default sort order is ascending. Multiple sort criteria are supported.") @RequestParam(value = "sort", required = false) List<String> sort);


    @ApiOperation(value = "getAllInsurerInvoicesByInsurer", notes = "", response = InsurerInvoiceDTO.class, responseContainer = "List", tags={ "insurer-invoice-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerInvoiceDTO.class) })
    @RequestMapping(value = "/api/insurer-invoices/findByInsurer/{insurer}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<InsurerInvoiceDTO>> getAllInsurerInvoicesByInsurerUsingGET(@ApiParam(value = "insurer",required=true ) @PathVariable("insurer") String insurer);


    @ApiOperation(value = "getAllInsurerInvoices", notes = "", response = InsurerInvoiceDTO.class, responseContainer = "List", tags={ "insurer-invoice-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerInvoiceDTO.class) })
    @RequestMapping(value = "/api/insurer-invoices",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<InsurerInvoiceDTO>> getAllInsurerInvoicesUsingGET(@ApiParam(value = "Page number of the requested page") @RequestParam(value = "page", required = false) Integer page,
        @ApiParam(value = "Size of a page") @RequestParam(value = "size", required = false) Integer size,
        @ApiParam(value = "Sorting criteria in the format: property(,asc|desc). Default sort order is ascending. Multiple sort criteria are supported.") @RequestParam(value = "sort", required = false) List<String> sort);


    @ApiOperation(value = "getAllInsurers", notes = "", response = InsurerDTO.class, responseContainer = "List", tags={ "insurer-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerDTO.class) })
    @RequestMapping(value = "/api/insurers",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<InsurerDTO>> getAllInsurersUsingGET(@ApiParam(value = "Page number of the requested page") @RequestParam(value = "page", required = false) Integer page,
        @ApiParam(value = "Size of a page") @RequestParam(value = "size", required = false) Integer size,
        @ApiParam(value = "Sorting criteria in the format: property(,asc|desc). Default sort order is ascending. Multiple sort criteria are supported.") @RequestParam(value = "sort", required = false) List<String> sort);


    @ApiOperation(value = "getAllMarshaledHealthInsurances", notes = "", response = HealthInsurance.class, responseContainer = "List", tags={ "health-insurance-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = HealthInsurance.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = HealthInsurance.class),
        @ApiResponse(code = 403, message = "Forbidden", response = HealthInsurance.class),
        @ApiResponse(code = 404, message = "Not Found", response = HealthInsurance.class) })
    @RequestMapping(value = "/api/health-insurances-marshaled",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<HealthInsurance>> getAllMarshaledHealthInsurancesUsingGET(@ApiParam(value = "Page number of the requested page") @RequestParam(value = "page", required = false) Integer page,
        @ApiParam(value = "Size of a page") @RequestParam(value = "size", required = false) Integer size,
        @ApiParam(value = "Sorting criteria in the format: property(,asc|desc). Default sort order is ascending. Multiple sort criteria are supported.") @RequestParam(value = "sort", required = false) List<String> sort);


    @ApiOperation(value = "getAllRelationships", notes = "", response = RelationshipDTO.class, responseContainer = "List", tags={ "relationship-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = RelationshipDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = RelationshipDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = RelationshipDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = RelationshipDTO.class) })
    @RequestMapping(value = "/api/relationships",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<List<RelationshipDTO>> getAllRelationshipsUsingGET(@ApiParam(value = "Page number of the requested page") @RequestParam(value = "page", required = false) Integer page,
        @ApiParam(value = "Size of a page") @RequestParam(value = "size", required = false) Integer size,
        @ApiParam(value = "Sorting criteria in the format: property(,asc|desc). Default sort order is ascending. Multiple sort criteria are supported.") @RequestParam(value = "sort", required = false) List<String> sort);


    @ApiOperation(value = "getCoveredActivity", notes = "", response = CoveredActivityDTO.class, tags={ "covered-activity-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = CoveredActivityDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = CoveredActivityDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = CoveredActivityDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = CoveredActivityDTO.class) })
    @RequestMapping(value = "/api/covered-activities/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<CoveredActivityDTO> getCoveredActivityUsingGET(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "getDepartment", notes = "", response = DepartmentDTO.class, tags={ "department-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = DepartmentDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = DepartmentDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = DepartmentDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = DepartmentDTO.class) })
    @RequestMapping(value = "/api/departments/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<DepartmentDTO> getDepartmentUsingGET(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "getHealthInsurance", notes = "", response = HealthInsuranceDTO.class, tags={ "health-insurance-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = HealthInsuranceDTO.class) })
    @RequestMapping(value = "/api/health-insurances/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<HealthInsuranceDTO> getHealthInsuranceUsingGET(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "getInsuranceCategory", notes = "", response = InsuranceCategoryDTO.class, tags={ "insurance-category-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsuranceCategoryDTO.class) })
    @RequestMapping(value = "/api/insurance-categories/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<InsuranceCategoryDTO> getInsuranceCategoryUsingGET(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "getInsurerInvoiceNumber", notes = "", response = InsurerInvoiceDTO.class, tags={ "insurer-invoice-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerInvoiceDTO.class) })
    @RequestMapping(value = "/api/insurer-invoices/findByInvoiceNumber/{invoiceNumber}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<InsurerInvoiceDTO> getInsurerInvoiceNumberUsingGET(@ApiParam(value = "invoiceNumber",required=true ) @PathVariable("invoiceNumber") Long invoiceNumber);


    @ApiOperation(value = "getInsurerInvoiceStatus", notes = "", response = InsurerInvoiceStatusDTO.class, tags={ "insurer-invoice-status-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerInvoiceStatusDTO.class) })
    @RequestMapping(value = "/api/insurer-invoice-statuses/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<InsurerInvoiceStatusDTO> getInsurerInvoiceStatusUsingGET(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "getInsurerInvoice", notes = "", response = InsurerInvoiceDTO.class, tags={ "insurer-invoice-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerInvoiceDTO.class) })
    @RequestMapping(value = "/api/insurer-invoices/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<InsurerInvoiceDTO> getInsurerInvoiceUsingGET(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "getInsurer", notes = "", response = InsurerDTO.class, tags={ "insurer-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerDTO.class) })
    @RequestMapping(value = "/api/insurers/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<InsurerDTO> getInsurerUsingGET(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "getRelationship", notes = "", response = RelationshipDTO.class, tags={ "relationship-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = RelationshipDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = RelationshipDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = RelationshipDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = RelationshipDTO.class) })
    @RequestMapping(value = "/api/relationships/{id}",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<RelationshipDTO> getRelationshipUsingGET(@ApiParam(value = "id",required=true ) @PathVariable("id") Long id);


    @ApiOperation(value = "isAuthenticated", notes = "", response = String.class, tags={ "account-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = String.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = String.class),
        @ApiResponse(code = 403, message = "Forbidden", response = String.class),
        @ApiResponse(code = 404, message = "Not Found", response = String.class) })
    @RequestMapping(value = "/api/authenticate",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.GET)
    ResponseEntity<String> isAuthenticatedUsingGET();


    @ApiOperation(value = "updateCoveredActivity", notes = "", response = CoveredActivityDTO.class, tags={ "covered-activity-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = CoveredActivityDTO.class),
        @ApiResponse(code = 201, message = "Created", response = CoveredActivityDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = CoveredActivityDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = CoveredActivityDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = CoveredActivityDTO.class) })
    @RequestMapping(value = "/api/covered-activities",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.PUT)
    ResponseEntity<CoveredActivityDTO> updateCoveredActivityUsingPUT(@ApiParam(value = "coveredActivityDTO" ,required=true ) @RequestBody CoveredActivityDTO coveredActivityDTO);


    @ApiOperation(value = "updateDepartment", notes = "", response = DepartmentDTO.class, tags={ "department-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = DepartmentDTO.class),
        @ApiResponse(code = 201, message = "Created", response = DepartmentDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = DepartmentDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = DepartmentDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = DepartmentDTO.class) })
    @RequestMapping(value = "/api/departments",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.PUT)
    ResponseEntity<DepartmentDTO> updateDepartmentUsingPUT(@ApiParam(value = "departmentDTO" ,required=true ) @RequestBody DepartmentDTO departmentDTO);


    @ApiOperation(value = "updateHealthInsurance", notes = "", response = HealthInsuranceDTO.class, tags={ "health-insurance-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 201, message = "Created", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = HealthInsuranceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = HealthInsuranceDTO.class) })
    @RequestMapping(value = "/api/health-insurances",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.PUT)
    ResponseEntity<HealthInsuranceDTO> updateHealthInsuranceUsingPUT(@ApiParam(value = "healthInsuranceDTO" ,required=true ) @RequestBody HealthInsuranceDTO healthInsuranceDTO);


    @ApiOperation(value = "updateInsuranceCategory", notes = "", response = InsuranceCategoryDTO.class, tags={ "insurance-category-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 201, message = "Created", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsuranceCategoryDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsuranceCategoryDTO.class) })
    @RequestMapping(value = "/api/insurance-categories",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.PUT)
    ResponseEntity<InsuranceCategoryDTO> updateInsuranceCategoryUsingPUT(@ApiParam(value = "insuranceCategoryDTO" ,required=true ) @RequestBody InsuranceCategoryDTO insuranceCategoryDTO);


    @ApiOperation(value = "updateInsurerInvoiceStatus", notes = "", response = InsurerInvoiceStatusDTO.class, tags={ "insurer-invoice-status-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 201, message = "Created", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerInvoiceStatusDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerInvoiceStatusDTO.class) })
    @RequestMapping(value = "/api/insurer-invoice-statuses",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.PUT)
    ResponseEntity<InsurerInvoiceStatusDTO> updateInsurerInvoiceStatusUsingPUT(@ApiParam(value = "insurerInvoiceStatusDTO" ,required=true ) @RequestBody InsurerInvoiceStatusDTO insurerInvoiceStatusDTO);


    @ApiOperation(value = "updateInsurerInvoice", notes = "", response = InsurerInvoiceDTO.class, tags={ "insurer-invoice-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 201, message = "Created", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerInvoiceDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerInvoiceDTO.class) })
    @RequestMapping(value = "/api/insurer-invoices",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.PUT)
    ResponseEntity<InsurerInvoiceDTO> updateInsurerInvoiceUsingPUT(@ApiParam(value = "insurerInvoiceDTO" ,required=true ) @RequestBody InsurerInvoiceDTO insurerInvoiceDTO);


    @ApiOperation(value = "updateInsurer", notes = "", response = InsurerDTO.class, tags={ "insurer-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InsurerDTO.class),
        @ApiResponse(code = 201, message = "Created", response = InsurerDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = InsurerDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = InsurerDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = InsurerDTO.class) })
    @RequestMapping(value = "/api/insurers",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.PUT)
    ResponseEntity<InsurerDTO> updateInsurerUsingPUT(@ApiParam(value = "insurerDTO" ,required=true ) @RequestBody InsurerDTO insurerDTO);


    @ApiOperation(value = "updateRelationship", notes = "", response = RelationshipDTO.class, tags={ "relationship-resource", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = RelationshipDTO.class),
        @ApiResponse(code = 201, message = "Created", response = RelationshipDTO.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = RelationshipDTO.class),
        @ApiResponse(code = 403, message = "Forbidden", response = RelationshipDTO.class),
        @ApiResponse(code = 404, message = "Not Found", response = RelationshipDTO.class) })
    @RequestMapping(value = "/api/relationships",
        produces = "*/*",
        consumes = "application/json",
        method = RequestMethod.PUT)
    ResponseEntity<RelationshipDTO> updateRelationshipUsingPUT(@ApiParam(value = "relationshipDTO" ,required=true ) @RequestBody RelationshipDTO relationshipDTO);

}
