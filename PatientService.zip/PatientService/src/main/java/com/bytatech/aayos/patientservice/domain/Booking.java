package com.bytatech.aayos.patientservice.domain;

import io.swagger.annotations.ApiModel;

import javax.persistence.*;

import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Objects;

/**
 * The Booking entity.
 * @author MayaSanjeev.
 */
@ApiModel(description = "The Booking entity. @author MayaSanjeev.")
@Entity
@Table(name = "booking")
public class Booking implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "booking_id")
    private Long bookingId;

    @Column(name = "doctor_name")
    private String doctorName;

    @Column(name = "estimate_time")
    private Instant estimateTime;

    @Column(name = "jhi_date")
    private LocalDate date;

    @Column(name = "token_number")
    private Integer tokenNumber;

    @Column(name = "date_of_booking")
    private LocalDate dateOfBooking;

    @Column(name = "time_of_booking")
    private Instant timeOfBooking;

    @Column(name = "admission_no")
    private Long admissionNo;

    @ManyToOne
    private Patient patient;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBookingId() {
        return bookingId;
    }

    public Booking bookingId(Long bookingId) {
        this.bookingId = bookingId;
        return this;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public Booking doctorName(String doctorName) {
        this.doctorName = doctorName;
        return this;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public Instant getEstimateTime() {
        return estimateTime;
    }

    public Booking estimateTime(Instant estimateTime) {
        this.estimateTime = estimateTime;
        return this;
    }

    public void setEstimateTime(Instant estimateTime) {
        this.estimateTime = estimateTime;
    }

    public LocalDate getDate() {
        return date;
    }

    public Booking date(LocalDate date) {
        this.date = date;
        return this;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Integer getTokenNumber() {
        return tokenNumber;
    }

    public Booking tokenNumber(Integer tokenNumber) {
        this.tokenNumber = tokenNumber;
        return this;
    }

    public void setTokenNumber(Integer tokenNumber) {
        this.tokenNumber = tokenNumber;
    }

    public LocalDate getDateOfBooking() {
        return dateOfBooking;
    }

    public Booking dateOfBooking(LocalDate dateOfBooking) {
        this.dateOfBooking = dateOfBooking;
        return this;
    }

    public void setDateOfBooking(LocalDate dateOfBooking) {
        this.dateOfBooking = dateOfBooking;
    }

    public Instant getTimeOfBooking() {
        return timeOfBooking;
    }

    public Booking timeOfBooking(Instant timeOfBooking) {
        this.timeOfBooking = timeOfBooking;
        return this;
    }

    public void setTimeOfBooking(Instant timeOfBooking) {
        this.timeOfBooking = timeOfBooking;
    }

    public Long getAdmissionNo() {
        return admissionNo;
    }

    public Booking admissionNo(Long admissionNo) {
        this.admissionNo = admissionNo;
        return this;
    }

    public void setAdmissionNo(Long admissionNo) {
        this.admissionNo = admissionNo;
    }

    public Patient getPatient() {
        return patient;
    }

    public Booking patient(Patient patient) {
        this.patient = patient;
        return this;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Booking booking = (Booking) o;
        if (booking.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), booking.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Booking{" +
            "id=" + getId() +
            ", bookingId=" + getBookingId() +
            ", doctorName='" + getDoctorName() + "'" +
            ", estimateTime='" + getEstimateTime() + "'" +
            ", date='" + getDate() + "'" +
            ", tokenNumber=" + getTokenNumber() +
            ", dateOfBooking='" + getDateOfBooking() + "'" +
            ", timeOfBooking='" + getTimeOfBooking() + "'" +
            ", admissionNo=" + getAdmissionNo() +
            "}";
    }
}
