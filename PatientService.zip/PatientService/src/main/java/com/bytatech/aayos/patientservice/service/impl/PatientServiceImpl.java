package com.bytatech.aayos.patientservice.service.impl;

import com.bytatech.aayos.patientservice.service.PatientService;
import com.bytatech.aayos.patientservice.domain.Country;
import com.bytatech.aayos.patientservice.domain.Patient;
import com.bytatech.aayos.patientservice.repository.PatientRepository;
import com.bytatech.aayos.patientservice.service.dto.BookingDTO;
import com.bytatech.aayos.patientservice.service.dto.CountryDTO;
import com.bytatech.aayos.patientservice.service.dto.FamilyRelationShipDTO;
import com.bytatech.aayos.patientservice.service.dto.InsurarDTO;
import com.bytatech.aayos.patientservice.service.dto.PatientDTO;
import com.bytatech.aayos.patientservice.service.dto.PrivateDetailsDTO;
import com.bytatech.aayos.patientservice.service.mapper.BookingMapper;
import com.bytatech.aayos.patientservice.service.mapper.CountryMapper;
import com.bytatech.aayos.patientservice.service.mapper.FamilyRelationShipMapper;
import com.bytatech.aayos.patientservice.service.mapper.InsurarMapper;
import com.bytatech.aayos.patientservice.service.mapper.PatientMapper;
import com.bytatech.aayos.patientservice.service.mapper.PrivateDetailsMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * Service Implementation for managing Patient.
 */
@Service
@Transactional
public class PatientServiceImpl implements PatientService{

    private final Logger log = LoggerFactory.getLogger(PatientServiceImpl.class);

    private final PatientRepository patientRepository;

    private final PatientMapper patientMapper;

    private final PrivateDetailsMapper privateDetailsMapper;
    
    private final InsurarMapper insurarsMapper;
    
    private final FamilyRelationShipMapper familyRelationShipsMapper;
    
    private final BookingMapper bookingMapper;
    
    private final  CountryMapper countryMapper;
    
    public PatientServiceImpl(PatientRepository patientRepository, PatientMapper patientMapper,PrivateDetailsMapper privateDetailsMapper,InsurarMapper insurarsMapper,FamilyRelationShipMapper familyRelationShipsMapper,BookingMapper bookingMapper,CountryMapper countryMapper) {
        this.patientRepository = patientRepository;
        this.patientMapper = patientMapper;
        this.privateDetailsMapper=privateDetailsMapper;
        this.insurarsMapper=insurarsMapper;
        this.familyRelationShipsMapper=familyRelationShipsMapper;
        this.bookingMapper=bookingMapper;
        this.countryMapper=countryMapper;
    }

    /**
     * Save a patient.
     *
     * @param patientDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public PatientDTO save(PatientDTO patientDTO) {
        log.debug("Request to save Patient : {}", patientDTO);
        Patient patient = patientMapper.toEntity(patientDTO);
        patient = patientRepository.save(patient);
        return patientMapper.toDto(patient);
    }

    /**
     * Get all the patients.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<PatientDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Patients");
        return patientRepository.findAll(pageable)
            .map(patientMapper::toDto);
    }

    /**
     * Get one patient by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public PatientDTO findOne(Long id) {
        log.debug("Request to get Patient : {}", id);
        Patient patient = patientRepository.findOne(id);
        return patientMapper.toDto(patient);
    }

    /**
     * Delete the patient by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Patient : {}", id);
        patientRepository.delete(id);
    }

	/* (non-Javadoc)
	 * @see com.bytatech.aayos.patientservice.service.PatientService#findByFamilyRelationShips_RelationShipAndPatient_Id(java.lang.String, java.lang.Long, org.springframework.data.domain.Pageable)
	 */
	@Override
	public Page<PatientDTO> findByFamilyRelationShips_RelationShipAndPatientId(String relationShip, Integer patientId,
			Pageable pageable) {
		   log.debug("Request to get all Patients");
	        return patientRepository.findByFamilyRelationShips_RelationShipAndPatientId(relationShip,patientId,
	    			pageable)
	            .map(patientMapper::toDto);
	}

	/* (non-Javadoc)
	 * @see com.bytatech.aayos.patientservice.service.PatientService#findByPrivateDetails_Patient_Id(java.lang.Long, org.springframework.data.domain.Pageable)
	 */
	@Override
	public Page<PrivateDetailsDTO> findByPrivateDetails_Patient_Id(Long id, Pageable pageable) {
		 log.debug("Request to get all Patients");
	        return patientRepository.findByPrivateDetails_Patient_Id(id,
	    			pageable)
	            .map(privateDetailsMapper::toDto);
	}

	/* (non-Javadoc)
	 * @see com.bytatech.aayos.patientservice.service.PatientService#findByInsurars_Patient_Id(java.lang.Long, org.springframework.data.domain.Pageable)
	 */
	@Override
	public Page<InsurarDTO> findByInsurars_Patient_Id(Long id, Pageable pageable) {
		 log.debug("Request to get all Insurar");
	        return patientRepository.findByInsurars_Patient_Id(id,pageable)
	            .map(insurarsMapper::toDto);
	}

	/* (non-Javadoc)
	 * @see com.bytatech.aayos.patientservice.service.PatientService#findByFamilyRelationships_Patient_Id(java.lang.Long, org.springframework.data.domain.Pageable)
	 */
	@Override
	public Page<FamilyRelationShipDTO> findByFamilyRelationShips_Patient_Id(Long id, Pageable pageable) {
		 log.debug("Request to get all FamilyRelationShip");
	        return patientRepository.findByFamilyRelationShips_Patient_Id(id,pageable)
	            .map(familyRelationShipsMapper::toDto);
	}

	/* (non-Javadoc)
	 * @see com.bytatech.aayos.patientservice.service.PatientService#findByBooking_Patient_Id(java.lang.Long, org.springframework.data.domain.Pageable)
	 */
	@Override
	public Page<BookingDTO> findByBooking_Patient_Id(Long id, Pageable pageable) {
		 log.debug("Request to get all FamilyRelationShip");
	        return patientRepository.findByBooking_Patient_Id(id,pageable)
	            .map(bookingMapper::toDto);
	}

	/* (non-Javadoc)
	 * @see com.bytatech.aayos.patientservice.service.PatientService#findByCountry_PatientId(java.lang.Long, org.springframework.data.domain.Pageable)
	 */
	@Override
	public CountryDTO findByCountry_PatientId(Long id) {
		 log.debug("Request to get all FamilyRelationShip");
	    Country country =  patientRepository.findByCountry_PatientId(id);
	           return countryMapper.toDto(country);

	}

}
