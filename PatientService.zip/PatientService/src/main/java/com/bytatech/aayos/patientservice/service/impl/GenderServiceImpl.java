package com.bytatech.aayos.patientservice.service.impl;

import com.bytatech.aayos.patientservice.service.GenderService;
import com.bytatech.aayos.patientservice.domain.Gender;
import com.bytatech.aayos.patientservice.repository.GenderRepository;
import com.bytatech.aayos.patientservice.service.dto.GenderDTO;
import com.bytatech.aayos.patientservice.service.mapper.GenderMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * Service Implementation for managing Gender.
 */
@Service
@Transactional
public class GenderServiceImpl implements GenderService{

    private final Logger log = LoggerFactory.getLogger(GenderServiceImpl.class);

    private final GenderRepository genderRepository;

    private final GenderMapper genderMapper;

    public GenderServiceImpl(GenderRepository genderRepository, GenderMapper genderMapper) {
        this.genderRepository = genderRepository;
        this.genderMapper = genderMapper;
    }

    /**
     * Save a gender.
     *
     * @param genderDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public GenderDTO save(GenderDTO genderDTO) {
        log.debug("Request to save Gender : {}", genderDTO);
        Gender gender = genderMapper.toEntity(genderDTO);
        gender = genderRepository.save(gender);
        return genderMapper.toDto(gender);
    }

    /**
     * Get all the genders.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<GenderDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Genders");
        return genderRepository.findAll(pageable)
            .map(genderMapper::toDto);
    }

    /**
     * Get one gender by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public GenderDTO findOne(Long id) {
        log.debug("Request to get Gender : {}", id);
        Gender gender = genderRepository.findOne(id);
        return genderMapper.toDto(gender);
    }

    /**
     * Delete the gender by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Gender : {}", id);
        genderRepository.delete(id);
    }
}
