package com.bytatech.aayos.patientservice.service;

import com.bytatech.aayos.patientservice.service.dto.HealthInsuranceDTO;
import com.bytatech.aayos.patientservice.service.dto.InsurarDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing Insurar.
 */
public interface InsurarService {

    /**
     * Save a insurar.
     *
     * @param insurarDTO the entity to save
     * @return the persisted entity
     */
    InsurarDTO save(InsurarDTO insurarDTO);

    /**
     * Get all the insurars.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<InsurarDTO> findAll(Pageable pageable);

    /**
     * Get the "id" insurar.
     *
     * @param id the id of the entity
     * @return the entity
     */
    InsurarDTO findOne(Long id);

    /**
     * Delete the "id" insurar.
     *
     * @param id the id of the entity
     */
    void delete(Long id);

	/**
	 * @param id
	 * @param pageable
	 * @return
	 */
	Page<HealthInsuranceDTO> findByHealthInsurances_Insurar_Id(Long id, Pageable pageable);
}
