/**
 * Service layer beans.
 */
package com.bytatech.aayos.patientservice.service;
