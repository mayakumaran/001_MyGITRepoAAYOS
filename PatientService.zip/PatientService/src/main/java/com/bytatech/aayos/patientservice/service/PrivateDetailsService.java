package com.bytatech.aayos.patientservice.service;

import com.bytatech.aayos.patientservice.service.dto.PrivateDetailsDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing PrivateDetails.
 */
public interface PrivateDetailsService {

    /**
     * Save a privateDetails.
     *
     * @param privateDetailsDTO the entity to save
     * @return the persisted entity
     */
    PrivateDetailsDTO save(PrivateDetailsDTO privateDetailsDTO);

    /**
     * Get all the privateDetails.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<PrivateDetailsDTO> findAll(Pageable pageable);

    /**
     * Get the "id" privateDetails.
     *
     * @param id the id of the entity
     * @return the entity
     */
    PrivateDetailsDTO findOne(Long id);

    /**
     * Delete the "id" privateDetails.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
