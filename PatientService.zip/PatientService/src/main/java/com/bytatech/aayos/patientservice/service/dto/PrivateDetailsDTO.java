package com.bytatech.aayos.patientservice.service.dto;


import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the PrivateDetails entity.
 */
public class PrivateDetailsDTO implements Serializable {

    private Long id;

    private String email;

    private String address;

    private String town;

    private Integer zipCode;

    private String socialMedia;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public Integer getZipCode() {
        return zipCode;
    }

    public void setZipCode(Integer zipCode) {
        this.zipCode = zipCode;
    }

    public String getSocialMedia() {
        return socialMedia;
    }

    public void setSocialMedia(String socialMedia) {
        this.socialMedia = socialMedia;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        PrivateDetailsDTO privateDetailsDTO = (PrivateDetailsDTO) o;
        if(privateDetailsDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), privateDetailsDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "PrivateDetailsDTO{" +
            "id=" + getId() +
            ", email='" + getEmail() + "'" +
            ", address='" + getAddress() + "'" +
            ", town='" + getTown() + "'" +
            ", zipCode=" + getZipCode() +
            ", socialMedia='" + getSocialMedia() + "'" +
            "}";
    }
}
