package com.bytatech.aayos.patientservice.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.bytatech.aayos.patientservice.service.PrivateDetailsService;
import com.bytatech.aayos.patientservice.web.rest.errors.BadRequestAlertException;
import com.bytatech.aayos.patientservice.web.rest.util.HeaderUtil;
import com.bytatech.aayos.patientservice.web.rest.util.PaginationUtil;
import com.bytatech.aayos.patientservice.service.dto.PrivateDetailsDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing PrivateDetails.
 */
@RestController
@RequestMapping("/api")
public class PrivateDetailsResource {

    private final Logger log = LoggerFactory.getLogger(PrivateDetailsResource.class);

    private static final String ENTITY_NAME = "privateDetails";

    private final PrivateDetailsService privateDetailsService;

    public PrivateDetailsResource(PrivateDetailsService privateDetailsService) {
        this.privateDetailsService = privateDetailsService;
    }

    /**
     * POST  /private-details : Create a new privateDetails.
     *
     * @param privateDetailsDTO the privateDetailsDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new privateDetailsDTO, or with status 400 (Bad Request) if the privateDetails has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/private-details")
    @Timed
    public ResponseEntity<PrivateDetailsDTO> createPrivateDetails(@RequestBody PrivateDetailsDTO privateDetailsDTO) throws URISyntaxException {
        log.debug("REST request to save PrivateDetails : {}", privateDetailsDTO);
        if (privateDetailsDTO.getId() != null) {
            throw new BadRequestAlertException("A new privateDetails cannot already have an ID", ENTITY_NAME, "idexists");
        }
        PrivateDetailsDTO result = privateDetailsService.save(privateDetailsDTO);
        return ResponseEntity.created(new URI("/api/private-details/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /private-details : Updates an existing privateDetails.
     *
     * @param privateDetailsDTO the privateDetailsDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated privateDetailsDTO,
     * or with status 400 (Bad Request) if the privateDetailsDTO is not valid,
     * or with status 500 (Internal Server Error) if the privateDetailsDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/private-details")
    @Timed
    public ResponseEntity<PrivateDetailsDTO> updatePrivateDetails(@RequestBody PrivateDetailsDTO privateDetailsDTO) throws URISyntaxException {
        log.debug("REST request to update PrivateDetails : {}", privateDetailsDTO);
        if (privateDetailsDTO.getId() == null) {
            return createPrivateDetails(privateDetailsDTO);
        }
        PrivateDetailsDTO result = privateDetailsService.save(privateDetailsDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, privateDetailsDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /private-details : get all the privateDetails.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of privateDetails in body
     */
    @GetMapping("/private-details")
    @Timed
    public ResponseEntity<List<PrivateDetailsDTO>> getAllPrivateDetails(Pageable pageable) {
        log.debug("REST request to get a page of PrivateDetails");
        Page<PrivateDetailsDTO> page = privateDetailsService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/private-details");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }

    /**
     * GET  /private-details/:id : get the "id" privateDetails.
     *
     * @param id the id of the privateDetailsDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the privateDetailsDTO, or with status 404 (Not Found)
     */
    @GetMapping("/private-details/{id}")
    @Timed
    public ResponseEntity<PrivateDetailsDTO> getPrivateDetails(@PathVariable Long id) {
        log.debug("REST request to get PrivateDetails : {}", id);
        PrivateDetailsDTO privateDetailsDTO = privateDetailsService.findOne(id);
        return ResponseUtil.wrapOrNotFound(Optional.ofNullable(privateDetailsDTO));
    }

    /**
     * DELETE  /private-details/:id : delete the "id" privateDetails.
     *
     * @param id the id of the privateDetailsDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/private-details/{id}")
    @Timed
    public ResponseEntity<Void> deletePrivateDetails(@PathVariable Long id) {
        log.debug("REST request to delete PrivateDetails : {}", id);
        privateDetailsService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
