package com.bytatech.aayos.patientservice.service.impl;

import com.bytatech.aayos.patientservice.service.InsurarService;
import com.bytatech.aayos.patientservice.domain.Insurar;
import com.bytatech.aayos.patientservice.repository.InsurarRepository;
import com.bytatech.aayos.patientservice.service.dto.HealthInsuranceDTO;
import com.bytatech.aayos.patientservice.service.dto.InsurarDTO;
import com.bytatech.aayos.patientservice.service.mapper.HealthInsuranceMapper;
import com.bytatech.aayos.patientservice.service.mapper.InsurarMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * Service Implementation for managing Insurar.
 */
@Service
@Transactional
public class InsurarServiceImpl implements InsurarService{

    private final Logger log = LoggerFactory.getLogger(InsurarServiceImpl.class);

    private final InsurarRepository insurarRepository;

    private final InsurarMapper insurarMapper;

    private final HealthInsuranceMapper healthMapper;
    
    public InsurarServiceImpl(InsurarRepository insurarRepository, InsurarMapper insurarMapper,HealthInsuranceMapper healthMapper) {
        this.insurarRepository = insurarRepository;
        this.insurarMapper = insurarMapper;
        this.healthMapper=healthMapper;
    }

    /**
     * Save a insurar.
     *
     * @param insurarDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public InsurarDTO save(InsurarDTO insurarDTO) {
        log.debug("Request to save Insurar : {}", insurarDTO);
        Insurar insurar = insurarMapper.toEntity(insurarDTO);
        insurar = insurarRepository.save(insurar);
        return insurarMapper.toDto(insurar);
    }

    /**
     * Get all the insurars.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<InsurarDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Insurars");
        return insurarRepository.findAll(pageable)
            .map(insurarMapper::toDto);
    }

    /**
     * Get one insurar by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public InsurarDTO findOne(Long id) {
        log.debug("Request to get Insurar : {}", id);
        Insurar insurar = insurarRepository.findOne(id);
        return insurarMapper.toDto(insurar);
    }

    /**
     * Delete the insurar by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Insurar : {}", id);
        insurarRepository.delete(id);
    }

	/* (non-Javadoc)
	 * @see com.bytatech.aayos.patientservice.service.InsurarService#findByHealthInsurance_Insurar_Id(java.lang.Long, org.springframework.data.domain.Pageable)
	 */
	@Override
	public Page<HealthInsuranceDTO> findByHealthInsurances_Insurar_Id(Long id, Pageable pageable) {
		  log.debug("Request to get all HealthInsurance");
	        return insurarRepository.findByHealthInsurances_Insurar_Id(id,pageable)
	        		
	            .map(healthMapper::toDto);

	}
}
