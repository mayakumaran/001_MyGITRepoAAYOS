package com.bytatech.aayos.patientservice.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;
import com.bytatech.aayos.patientservice.domain.Booking;
import com.bytatech.aayos.patientservice.domain.Country;
import com.bytatech.aayos.patientservice.domain.FamilyRelationShip;
import com.bytatech.aayos.patientservice.domain.HealthInsurance;
import com.bytatech.aayos.patientservice.domain.Insurar;
import com.bytatech.aayos.patientservice.domain.Patient;

import com.bytatech.aayos.patientservice.model.BookingModel;
import com.bytatech.aayos.patientservice.model.CountryModel;
import com.bytatech.aayos.patientservice.model.FamilyRelationShipModel;
import com.bytatech.aayos.patientservice.model.GenderModel;
import com.bytatech.aayos.patientservice.model.HealthInsuranceModel;
import com.bytatech.aayos.patientservice.model.InsurarModel;
import com.bytatech.aayos.patientservice.model.PatientModel;
import com.bytatech.aayos.patientservice.repository.PatientRepository;
import com.bytatech.aayos.patientservice.service.CountryService;
import com.bytatech.aayos.patientservice.service.InsurarService;
import com.bytatech.aayos.patientservice.service.PatientService;
import com.bytatech.aayos.patientservice.web.rest.errors.BadRequestAlertException;
import com.bytatech.aayos.patientservice.web.rest.util.HeaderUtil;
import com.bytatech.aayos.patientservice.web.rest.util.PaginationUtil;
import com.bytatech.aayos.patientservice.service.dto.BookingDTO;
import com.bytatech.aayos.patientservice.service.dto.CountryDTO;
import com.bytatech.aayos.patientservice.service.dto.FamilyRelationShipDTO;
import com.bytatech.aayos.patientservice.service.dto.HealthInsuranceDTO;
import com.bytatech.aayos.patientservice.service.dto.InsurarDTO;
import com.bytatech.aayos.patientservice.service.dto.PatientDTO;
import com.bytatech.aayos.patientservice.service.dto.PrivateDetailsDTO;
import com.bytatech.aayos.patientservice.service.mapper.*;


import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Patient.
 */
@RestController
@RequestMapping("/api")
public class PatientResource {

    private final Logger log = LoggerFactory.getLogger(PatientResource.class);

    private static final String ENTITY_NAME = "patient";

    private final PatientService patientService;
    private final PatientRepository repo;
    private final CountryService countryservice;
    
    private final  PatientMapper patientMapper;
	private final GenderMapper genderMapper;
	private final PrivateDetailsMapper privateDetailMapper;
	private final InsurarMapper insurarMapper;
	private final FamilyRelationShipMapper familyRelationShipsMapper;
	private final InsurarMapper insurarsMapper;
	private final BookingMapper bookingMapper;
	private final HealthInsuranceMapper healthMapper;
	private final CountryMapper countryMapper;
	
	@Autowired
	private InsurarService insurarService;
	
    public PatientResource(PatientService patientService,CountryService countryservice,PatientRepository repo ,PatientMapper patientMapper,GenderMapper genderMapper,PrivateDetailsMapper privateDetailMapper,InsurarMapper insurarMapper,FamilyRelationShipMapper familyRelationShipsMapper,InsurarMapper insurarsMapper,BookingMapper bookingMapper,HealthInsuranceMapper healthMapper,CountryMapper countryMapper) {
        this.patientService = patientService;
        this.repo=repo;

        this.patientMapper = patientMapper;
        this.genderMapper=genderMapper;
        this.privateDetailMapper=privateDetailMapper;
        this. insurarMapper= insurarMapper;
        this.familyRelationShipsMapper=familyRelationShipsMapper;
        this.insurarsMapper=insurarsMapper;
        this.bookingMapper=bookingMapper;
        this. healthMapper= healthMapper;
        this.countryservice=countryservice;
        this.countryMapper=countryMapper;
    }

    /**
     * POST  /patients : Create a new patient.
     *
     * @param patientDTO the patientDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new patientDTO, or with status 400 (Bad Request) if the patient has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/patients")
    @Timed
    public ResponseEntity<PatientDTO> createPatient(@RequestBody PatientDTO patientDTO) throws URISyntaxException {
        log.debug("REST request to save Patient : {}", patientDTO);
        
        if (patientDTO.getId() != null) {
            throw new BadRequestAlertException("A new patient cannot already have an ID", ENTITY_NAME, "idexists");
        }
        
      
        PatientDTO result = patientService.save(patientDTO);
        
        return ResponseEntity.created(new URI("/api/patients/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /patients : Updates an existing patient.
     *
     * @param patientDTO the patientDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated patientDTO,
     * or with status 400 (Bad Request) if the patientDTO is not valid,
     * or with status 500 (Internal Server Error) if the patientDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/patients")
    @Timed
    public ResponseEntity<PatientDTO> updatePatient(@RequestBody PatientDTO patientDTO) throws URISyntaxException {
    	
        log.debug("REST request to update Patient : {}", patientDTO);
        
        if (patientDTO.getId() == null) {
            return createPatient(patientDTO);
        }
        
        PatientDTO result = patientService.save(patientDTO);
        
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, patientDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /patients : get all the patients.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of patients in body
     */
    @GetMapping("/patients")
    @Timed
    public ResponseEntity<List<PatientModel>> getAllPatients(Pageable pageable) {
    	
        log.debug("REST request to get a page of Patients");
        
        Page<PatientDTO> page = patientService.findAll(pageable);
        
        List<PatientModel> list=new ArrayList<>();
        
        for(PatientDTO dto:page){
        	Long id=dto.getId();
        	
        	Patient patient=repo.findOne(id);
        	
            PatientModel PatientModel =	getPatient(patient);
          
                
            list.add(PatientModel);
        	
        }
        
        Page<PatientModel>pageOfpatientModel=new PageImpl<PatientModel>(list, new PageRequest(0,1), list.size());
        
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/patients");
        
        return new ResponseEntity<>(pageOfpatientModel.getContent(), headers, HttpStatus.OK);
    }

  
    
    public PatientModel getPatient(Patient patient){
    	
    	Long id=patient.getId();
    	
    	 List<InsurarDTO> insurarDTO  = patientService.findByInsurars_Patient_Id(id, new PageRequest(0, 1)).getContent();
    	 
         List<BookingDTO> bookingDTO=patientService.findByBooking_Patient_Id(id, new PageRequest(0, 1)).getContent();
         
         List<FamilyRelationShipDTO>   familyDTO= patientService.findByFamilyRelationShips_Patient_Id(id,new PageRequest(0, 1)).getContent();
         
         CountryDTO countryDTO = patientService.findByCountry_PatientId(id);
         
         PatientModel PatientModel = new PatientModel();
         
         if(patient!=null){
         PatientModel.setId(patient.getId());
         PatientModel.setFirstName(patient.getFirstName()); 
         PatientModel.setLastName(patient.getLastName());
         PatientModel.setDateOfBirth(patient.getDate());
         PatientModel.setPatientId(patient.getPatientId());
         PatientModel.setDateOfBirth(patient.getDateOfBirth());
         PatientModel.setPhoneNo(patient.getPhoneNo());
         PatientModel.setPlace(patient.getPlace());
         PatientModel.setPrivateDetails(patient.getPrivateDetails()); 
       
          if(patient.getGender()!=null){
           GenderModel gender= new GenderModel(patient.getGender().getId(),patient.getGender().getGender());
           PatientModel.setGender(gender);
        }
      }
       if(countryDTO!=null){
     	  
         CountryModel countryModel=new CountryModel(countryDTO.getId(),countryDTO.getCode(),countryDTO.getName(),countryDTO.getPhonecode());
         PatientModel.setCountry(countryModel);
       }
         if(bookingDTO!=null){
         	List<BookingModel>bookingList=new ArrayList<>();
         	for(Booking bk:bookingMapper.toEntity(bookingDTO)){
         		BookingModel booking=new BookingModel(bk.getId(),bk.getBookingId(),bk.getDoctorName(),bk.getEstimateTime(),bk.getDate(),bk.getTokenNumber(),bk.getDateOfBooking(),bk.getTimeOfBooking(),bk.getAdmissionNo());
         	bookingList.add(booking);
         	}
         	PatientModel.setBookings(bookingList);
         }
         if(familyDTO!=null){
         	List<FamilyRelationShipModel> familyList=new ArrayList<>();
         	for(FamilyRelationShip f:familyRelationShipsMapper.toEntity(familyDTO)){
         	FamilyRelationShipModel family=new FamilyRelationShipModel(f.getId(),f.getRelationShip());
         	familyList.add(family);
         	}
         	PatientModel.setFamilyRelationShips(familyList);
         }
         
         if(insurarDTO!=null){
         	
         List<InsurarModel> insurarList=new ArrayList<>();
         
         List<HealthInsuranceModel> healthList=new ArrayList<>();
         
         for(Insurar i:insurarsMapper.toEntity(insurarDTO)){
         	
         	List<HealthInsuranceDTO> healthDTO=insurarService.findByHealthInsurances_Insurar_Id(i.getId(),new PageRequest(0, 2)).getContent();
         	
         	InsurarModel insurar=null;
         	if(healthDTO!=null){
         		
         		List<HealthInsurance> health=healthMapper.toEntity(healthDTO);
         		
         		for(HealthInsurance h:health){
         		HealthInsuranceModel healthMarshaled=new HealthInsuranceModel(h.getId(),h.getInsuranceNumber(),h.getExpiraryDate());
         		healthList.add(healthMarshaled);
         		
         		 insurar=new InsurarModel(i.getId(),i.getInsurarName(),healthList);
         		insurarList.add(insurar);
         		}
         		
         	   }
         }
         
         		PatientModel.setInsurars(insurarList);
         		
         		
         }
         
         
         return PatientModel;
    }
    
    
    public List<PatientModel> getListOfPatientModel(Page<PatientDTO> page){
    	
   	 List<PatientModel> list=new ArrayList<>();
        
        for(PatientDTO dto:page){
        	Long id=dto.getId();
        	
        	Patient patient=repo.findOne(id);
        	
            PatientModel PatientModel =	getPatient(patient);
          
                
            list.add(PatientModel);
        	
        }
        return list;
   }
    /**
     * GET  /patientsMarsheld/:id : get the "id" patient.
     *
     * @param id the id of the patientDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the patientDTO, or with status 404 (Not Found)
     */ 
    @GetMapping("/patientsMarsheld/{id}")
    @Timed
    public ResponseEntity<PatientModel> getPatientMarsheld(@PathVariable Long id) {
    	
        log.debug("REST request to get Patient : {}", id);
        
        Patient patient = repo.findOne(id);
      
        
        PatientModel  PatientModel =  getPatient(patient);
     
        return ResponseUtil.wrapOrNotFound(Optional.ofNullable(PatientModel));
    }
    
    /**
     * GET  /patients/:id : get the "id" patient.
     *
     * @param id the id of the patientDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the patientDTO, or with status 404 (Not Found)
     */
    @GetMapping("/patients/{id}")
    @Timed
    public ResponseEntity<PatientDTO> getPatient(@PathVariable Long id) {
        log.debug("REST request to get Patient : {}", id);
        PatientDTO patientDTO = patientService.findOne(id);
        return ResponseUtil.wrapOrNotFound(Optional.ofNullable(patientDTO));
    }

    /**
     * DELETE  /patients/:id : delete the "id" patient.
     *
     * @param id the id of the patientDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/patients/{id}")
    @Timed
    public ResponseEntity<Void> deletePatient(@PathVariable Long id) {
        log.debug("REST request to delete Patient : {}", id);
        patientService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
    
    /**
     * GET  /prescriptions/findByFamilyRelationShips_RelationShip/{relationShip}:relationShip : get the "id" FamilyRelationShips.
     *
     * @param id the id of the FamilyRelationShipsDTOs to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the FamilyRelationShipsDTO, or with status 404 (Not Found)
     */
    @GetMapping("/patients/findByFamilyRelationShips_RelationShipAndPatient_Id/{relationShip}/{patientId}")
    @Timed
    public ResponseEntity<List<PatientDTO>> getPatientByFamilyRelationShip_RelationShipAndPatientId(@PathVariable String relationShip,@PathVariable Integer patientId,Pageable pageable) {
        log.debug("REST request to get Prescription : {}",relationShip);
        Page<PatientDTO> prescriptionDTO = patientService.findByFamilyRelationShips_RelationShipAndPatientId(relationShip,patientId,pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(prescriptionDTO,"/api/patients/findFamilyRelationShip_RelationShip/{relationShip}/{patientId}");
        return new ResponseEntity<>(prescriptionDTO.getContent(), headers, HttpStatus.OK);
    }
    
    /**
     * GET  /patients/findByPrivateDetails_Patient_Id/{id}:relationShip : get the "id" PrivateDetails.
     *
     * @param id the id of the PrivateDetailsDTOs to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the PrivateDetailsDTO, or with status 404 (Not Found)
     */
    @GetMapping("/patients/findByPrivateDetails_Patient_Id/{id}")
    @Timed
    public ResponseEntity<List<PrivateDetailsDTO>> getPatientByPrivateDetails_Patient_Id(@PathVariable Long id,Pageable pageable) {
        log.debug("REST request to get Prescription : {}",id);
        Page<PrivateDetailsDTO> prescriptionDTO = patientService.findByPrivateDetails_Patient_Id(id,pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(prescriptionDTO,"/api/patients/findByPrivateDetails_Patient_Id/{id}");
        return new ResponseEntity<>(prescriptionDTO.getContent(), headers, HttpStatus.OK);
    }
    
    
    /**
     * GET  /patients/findByInsurars_Patient_Id/{id}:relationShip : get the "id"Insurars.
     *
     * @param id the id of the InsurarsDTOs to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the InsurarsDTO, or with status 404 (Not Found)
     */
    @GetMapping("/patients/findByInsurars_Patient_Id/{id}")
    @Timed
    public ResponseEntity<List<InsurarDTO>> getPatientByInsurars_Id(@PathVariable Long id,Pageable pageable) {
        log.debug("REST request to get Prescription : {}",id);
        Page<InsurarDTO> insurarDTO = patientService.findByInsurars_Patient_Id(id,pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(insurarDTO,"/api/patients/findByInsurars_Patient_Id/{id}");
        return new ResponseEntity<>(insurarDTO.getContent(), headers, HttpStatus.OK);
    }
    
    /**
     * GET  /patients/findByFamilyRelationships_Patient_Id/{id}:relationShip : get the "id" FamilyRelationships.
     *
     * @param id the id of the FamilyRelationshipsDTOs to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the FamilyRelationshipsDTO, or with status 404 (Not Found)
     */
    @GetMapping("/patients/findByFamilyRelationships_Patient_Id/{id}")
    @Timed
    public ResponseEntity<List<FamilyRelationShipDTO>> getPatientByFamilyRelationships_Patient_Id(@PathVariable Long id,Pageable pageable) {
        log.debug("REST request to get Prescription : {}",id);
        Page<FamilyRelationShipDTO> familyRelationShipDTO = patientService.findByFamilyRelationShips_Patient_Id(id,pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(familyRelationShipDTO,"/api/patients/findByFamilyRelationships_Patient_Id/{id}");
        return new ResponseEntity<>(familyRelationShipDTO.getContent(), headers, HttpStatus.OK);
    }
    
    /**
     * GET  /patients/findByBooking_Patient_Id/{id}:relationShip : get the "id" Booking.
     *
     * @param id the id of the Booking to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the BookingDTO, or with status 404 (Not Found)
     */
    @GetMapping("/patients/findByBooking_Patient_Id/{id}")
    @Timed
    public ResponseEntity<List<BookingDTO>> getPatientByBooking_Patient_Id(@PathVariable Long id,Pageable pageable) {
        log.debug("REST request to get Prescription : {}",id);
        Page<BookingDTO> familyRelationShipDTO = patientService.findByBooking_Patient_Id(id,pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(familyRelationShipDTO,"/api/patients/findByBooking_Patient_Id/{id}");
        return new ResponseEntity<>(familyRelationShipDTO.getContent(), headers, HttpStatus.OK);
    }
    
    /**
     * GET  /patients/findByCountry_PatientId/{id}:relationShip : get the "id" Country.
     *
     * @param id the id of the Booking to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the BookingDTO, or with status 404 (Not Found)
     */
    @GetMapping("/patients/findByCountry_PatientId/{id}")
    @Timed
    public ResponseEntity<CountryDTO> getCountryByPatientId(@PathVariable Long id) {
        log.debug("REST request to get Prescription : {}",id);
      CountryDTO countryDTO = patientService.findByCountry_PatientId(id);
      return ResponseUtil.wrapOrNotFound(Optional.ofNullable(countryDTO));
    }
    
    
    
    /**
     * POST  /patients : Create a new patient.
     *
     * @param patientDTO the patientDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new patientDTO, or with status 400 (Bad Request) if the patient has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/phnumber/patients")
    @Timed
    public ResponseEntity<PatientDTO> createPatientByValidatingPh(@RequestBody PatientDTO patientDTO) throws URISyntaxException {
        log.debug("REST request to save Patient : {}", patientDTO);
        PatientDTO result=null;
        if (patientDTO.getId() != null) {
            throw new BadRequestAlertException("A new patient cannot already have an ID", ENTITY_NAME, "idexists");
        }
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
		try {
			CountryDTO country=countryservice.findOne(patientDTO.getCountryId());
		    PhoneNumber phoneNumberProto = phoneUtil.parse("+"+country.getPhonecode()+patientDTO.getPhoneNo(), null);
		    boolean isValid = phoneUtil.isValidNumber(phoneNumberProto); // returns true if valid
		    System.out.println("COUNTRY CODE:     "+patientDTO.getCountryId());
		    if (isValid) {
		    	  System.out.println(">>>>>>>>>>>>>>>   VALIDNUMBER OR NOT:  "+isValid+country.getPhonecode()+patientDTO.getPhoneNo());
		    	 result = patientService.save(patientDTO);
		    	System.out.println(">>>>>>>>>>>>>>> CREATE CONTACT"+ createContact(country.getPhonecode()+patientDTO.getPhoneNo()));
			        
			     
			        System.out.println("%%%%%%%%%%%%%%%%%%%%%  SMS STATUS: "+ sms(patientDTO,country.getPhonecode()));
		       
		    } else {
		        // Do necessary actions if its not valid 
		    	System.out.println(">>>>>>>>>>>>>PH: not Valid "+patientDTO);
		    }
		} catch (NumberParseException e) {
		    System.err.println("NumberParseException was thrown: " + e.toString());
		}
      
		 
        return ResponseEntity.created(new URI("/api/phnumber/patients" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }
    
    	public String createContact(String phoneNumber){
	
    		try {
    			// Construct data
    			String apiKey = "apikey=" + "nJHgvDF3N8s-p9oonAesNgBHJ68FKb69W5hbOAV9sv";
    			String numbers = "&numbers=" + phoneNumber;
    			String group_id = "&group_id=" + "0";
    			
    			// Send data
    			HttpURLConnection conn = (HttpURLConnection) new URL("https://api.txtlocal.com/create_contacts/?").openConnection();
    			String data = apiKey + numbers + group_id;
    			conn.setDoOutput(true);
    			conn.setRequestMethod("POST");
    			conn.setRequestProperty("Content-Length", Integer.toString(data.length()));
    			conn.getOutputStream().write(data.getBytes("UTF-8"));
    			final BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
    			final StringBuffer stringBuffer = new StringBuffer();
    			String line;
    			while ((line = rd.readLine()) != null) {
    				stringBuffer.append(line);
    			}
    			rd.close();
    			
    			return stringBuffer.toString();
    		} catch (Exception e) {
    			System.out.println("Error SMS "+e);
    			return "Error "+e;
    		}
    	}
	


public String sms(PatientDTO patient,String phoneCode){
	
	
	try {
		// Construct data
		String apiKey = "apikey=" + "nJHgvDF3N8s-p9oonAesNgBHJ68FKb69W5hbOAV9sv";
		String message = "&message=" + patient.getFirstName();
		String sender = "&sender=" + "TXTLCL";
		String numbers = "&numbers=" + phoneCode+patient.getPhoneNo();
		
		// Send data
		HttpURLConnection conn = (HttpURLConnection) new URL("https://api.txtlocal.com/send/?").openConnection();
		String data = apiKey + numbers + message + sender;
		conn.setDoOutput(true);
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-Length", Integer.toString(data.length()));
		conn.getOutputStream().write(data.getBytes("UTF-8"));
		final BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		final StringBuffer stringBuffer = new StringBuffer();
		String line;
		while ((line = rd.readLine()) != null) {
			stringBuffer.append(line);
		}
		rd.close();
		
		return stringBuffer.toString();
	} catch (Exception e) {
		System.out.println("Error SMS "+e);
		return "Error "+e;
	}
}



}
