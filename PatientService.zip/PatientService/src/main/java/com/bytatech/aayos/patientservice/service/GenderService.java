package com.bytatech.aayos.patientservice.service;

import com.bytatech.aayos.patientservice.service.dto.GenderDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing Gender.
 */
public interface GenderService {

    /**
     * Save a gender.
     *
     * @param genderDTO the entity to save
     * @return the persisted entity
     */
    GenderDTO save(GenderDTO genderDTO);

    /**
     * Get all the genders.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<GenderDTO> findAll(Pageable pageable);

    /**
     * Get the "id" gender.
     *
     * @param id the id of the entity
     * @return the entity
     */
    GenderDTO findOne(Long id);

    /**
     * Delete the "id" gender.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
