package com.bytatech.aayos.patientservice.service.mapper;

import com.bytatech.aayos.patientservice.domain.*;
import com.bytatech.aayos.patientservice.service.dto.FamilyRelationShipDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity FamilyRelationShip and its DTO FamilyRelationShipDTO.
 */
@Mapper(componentModel = "spring", uses = {PatientMapper.class})
public interface FamilyRelationShipMapper extends EntityMapper<FamilyRelationShipDTO, FamilyRelationShip> {

    @Mapping(source = "patient.id", target = "patientId")
    FamilyRelationShipDTO toDto(FamilyRelationShip familyRelationShip); 

    @Mapping(source = "patientId", target = "patient")
    FamilyRelationShip toEntity(FamilyRelationShipDTO familyRelationShipDTO);

    default FamilyRelationShip fromId(Long id) {
        if (id == null) {
            return null;
        }
        FamilyRelationShip familyRelationShip = new FamilyRelationShip();
        familyRelationShip.setId(id);
        return familyRelationShip;
    }
}
