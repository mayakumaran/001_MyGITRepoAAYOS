package com.bytatech.aayos.patientservice.service.impl;

import com.bytatech.aayos.patientservice.service.FamilyRelationShipService;
import com.bytatech.aayos.patientservice.domain.FamilyRelationShip;
import com.bytatech.aayos.patientservice.repository.FamilyRelationShipRepository;
import com.bytatech.aayos.patientservice.service.dto.FamilyRelationShipDTO;
import com.bytatech.aayos.patientservice.service.mapper.FamilyRelationShipMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * Service Implementation for managing FamilyRelationShip.
 */
@Service
@Transactional
public class FamilyRelationShipServiceImpl implements FamilyRelationShipService{

    private final Logger log = LoggerFactory.getLogger(FamilyRelationShipServiceImpl.class);

    private final FamilyRelationShipRepository familyRelationShipRepository;

    private final FamilyRelationShipMapper familyRelationShipMapper;

    public FamilyRelationShipServiceImpl(FamilyRelationShipRepository familyRelationShipRepository, FamilyRelationShipMapper familyRelationShipMapper) {
        this.familyRelationShipRepository = familyRelationShipRepository;
        this.familyRelationShipMapper = familyRelationShipMapper;
    }

    /**
     * Save a familyRelationShip.
     *
     * @param familyRelationShipDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public FamilyRelationShipDTO save(FamilyRelationShipDTO familyRelationShipDTO) {
        log.debug("Request to save FamilyRelationShip : {}", familyRelationShipDTO);
        FamilyRelationShip familyRelationShip = familyRelationShipMapper.toEntity(familyRelationShipDTO);
        familyRelationShip = familyRelationShipRepository.save(familyRelationShip);
        return familyRelationShipMapper.toDto(familyRelationShip);
    }

    /**
     * Get all the familyRelationShips.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<FamilyRelationShipDTO> findAll(Pageable pageable) {
        log.debug("Request to get all FamilyRelationShips");
        return familyRelationShipRepository.findAll(pageable)
            .map(familyRelationShipMapper::toDto);
    }

    /**
     * Get one familyRelationShip by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public FamilyRelationShipDTO findOne(Long id) {
        log.debug("Request to get FamilyRelationShip : {}", id);
        FamilyRelationShip familyRelationShip = familyRelationShipRepository.findOne(id);
        return familyRelationShipMapper.toDto(familyRelationShip);
    }

    /**
     * Delete the familyRelationShip by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete FamilyRelationShip : {}", id);
        familyRelationShipRepository.delete(id);
    }
}
