package com.bytatech.aayos.patientservice.service;

import com.bytatech.aayos.patientservice.service.dto.BookingDTO;
import com.bytatech.aayos.patientservice.service.dto.CountryDTO;
import com.bytatech.aayos.patientservice.service.dto.FamilyRelationShipDTO;
import com.bytatech.aayos.patientservice.service.dto.InsurarDTO;
import com.bytatech.aayos.patientservice.service.dto.PatientDTO;
import com.bytatech.aayos.patientservice.service.dto.PrivateDetailsDTO;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing Patient.
 */
public interface PatientService {

    /**
     * Save a patient.
     *
     * @param patientDTO the entity to save
     * @return the persisted entity
     */
    PatientDTO save(PatientDTO patientDTO);

    /**
     * Get all the patients.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<PatientDTO> findAll(Pageable pageable);

    /**
     * Get the "id" patient.
     *
     * @param id the id of the entity
     * @return the entity
     */
    PatientDTO findOne(Long id);

    
    /**
     * Delete the "id" patient.
     *
     * @param id the id of the entity
     */
    void delete(Long id);

	/**
	 * @param relationShip
	 * @param patientId
	 * @param pageable
	 * @return
	 */
	Page<PatientDTO> findByFamilyRelationShips_RelationShipAndPatientId(String relationShip, Integer patientId,
			Pageable pageable);

	/**
	 * @param id
	 * @param pageable
	 * @return
	 */
	Page<PrivateDetailsDTO> findByPrivateDetails_Patient_Id(Long id, Pageable pageable);

	/**
	 * @param id
	 * @param pageable
	 * @return
	 */
	Page<InsurarDTO> findByInsurars_Patient_Id(Long id, Pageable pageable);

	/**
	 * @param id
	 * @param pageable
	 * @return
	 */
	Page<FamilyRelationShipDTO> findByFamilyRelationShips_Patient_Id(Long id, Pageable pageable);

	/**
	 * @param id
	 * @param pageable
	 * @return
	 */
	Page<BookingDTO> findByBooking_Patient_Id(Long id, Pageable pageable);

	/**
	 * @param id
	 * @param pageable
	 * @return
	 */
CountryDTO findByCountry_PatientId(Long id);

	
}
