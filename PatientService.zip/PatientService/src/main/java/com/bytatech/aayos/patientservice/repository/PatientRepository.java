package com.bytatech.aayos.patientservice.repository;

import com.bytatech.aayos.patientservice.domain.Booking;
import com.bytatech.aayos.patientservice.domain.Country;
import com.bytatech.aayos.patientservice.domain.FamilyRelationShip;
import com.bytatech.aayos.patientservice.domain.Insurar;
import com.bytatech.aayos.patientservice.domain.Patient;
import com.bytatech.aayos.patientservice.domain.PrivateDetails;
import com.bytatech.aayos.patientservice.service.dto.FamilyRelationShipDTO;
import com.bytatech.aayos.patientservice.service.dto.PatientDTO;

import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;


/**
 * Spring Data JPA repository for the Patient entity.
 */
@SuppressWarnings("unused")
@Repository
public interface PatientRepository extends JpaRepository<Patient, Long> {

	/**
	 * @param relationShip
	 * @param patientId
	 * @param pageable
	 * @return
	 */
	Page<Patient> findByFamilyRelationShips_RelationShipAndPatientId(String relationShip, Integer patientId,
			Pageable pageable);

	/**
	 * @param id
	 * @param pageable
	 * @return
	 */
	@Query(value="Select distinct  pd  from Patient p Join p.privateDetails  pd  Where p.id =:id ")
	Page<PrivateDetails> findByPrivateDetails_Patient_Id(@Param("id")Long id, Pageable pageable);

	/**
	 * @param id
	 * @param pageable
	 * @return
	 */
	@Query(value="Select distinct  ins  from Patient p Join p.insurars   ins  Where p.id =:id ")
	Page<Insurar> findByInsurars_Patient_Id(@Param("id")Long id, Pageable pageable);

	/**
	 * @param id
	 * @param pageable
	 * @return
	 */
	@Query(value="Select distinct  fmly  from Patient p Join p.familyRelationShips  fmly  Where p.id =:id ")
	Page<FamilyRelationShip> findByFamilyRelationShips_Patient_Id(@Param("id")Long id, Pageable pageable);

	/**
	 * @param id
	 * @param pageable
	 * @return
	 */
	@Query(value="Select distinct  bk  from Patient p Join p.bookings  bk  Where p.id =:id ")
	Page<Booking> findByBooking_Patient_Id(@Param("id")Long id, Pageable pageable);

	/**
	 * @param id
	 * @param pageable
	 * @return
	 */
	@Query(value="Select distinct  c  from Patient p Join p.country  c  Where p.id =:id ")
	Country findByCountry_PatientId(@Param("id")Long id);

	
	

	
	
	
	

}
