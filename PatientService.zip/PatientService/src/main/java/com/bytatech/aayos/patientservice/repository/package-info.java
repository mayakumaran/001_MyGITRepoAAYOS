/**
 * Spring Data JPA repositories.
 */
package com.bytatech.aayos.patientservice.repository;
