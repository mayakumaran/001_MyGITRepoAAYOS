package com.bytatech.aayos.patientservice.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.bytatech.aayos.patientservice.client.insuranceservice.api.ApiApi;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.InsurerDTO;
import com.bytatech.aayos.patientservice.domain.HealthInsurance;
import com.bytatech.aayos.patientservice.domain.Insurar;
import com.bytatech.aayos.patientservice.model.HealthInsuranceModel;
import com.bytatech.aayos.patientservice.model.InsurarModel;
import com.bytatech.aayos.patientservice.service.InsurarService;
import com.bytatech.aayos.patientservice.web.rest.errors.BadRequestAlertException;
import com.bytatech.aayos.patientservice.web.rest.util.HeaderUtil;
import com.bytatech.aayos.patientservice.web.rest.util.PaginationUtil;
import com.bytatech.aayos.patientservice.service.dto.BookingDTO;
import com.bytatech.aayos.patientservice.service.dto.HealthInsuranceDTO;
import com.bytatech.aayos.patientservice.service.dto.InsurarDTO;
import com.bytatech.aayos.patientservice.service.mapper.HealthInsuranceMapper;
import com.bytatech.aayos.patientservice.service.mapper.InsurarMapper;

import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Insurar.
 */
@RestController
@RequestMapping("/api")
public class InsurarResource {

    private final Logger log = LoggerFactory.getLogger(InsurarResource.class);

    private static final String ENTITY_NAME = "insurar";

    private final InsurarService insurarService;

    @Autowired
    private  HealthInsuranceMapper healthMapper;
    
    @Autowired
    ApiApi api;
    public InsurarResource(InsurarService insurarService) {
        this.insurarService = insurarService;
    }

    /**
     * POST  /insurars : Create a new insurar.
     *
     * @param insurarDTO the insurarDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new insurarDTO, or with status 400 (Bad Request) if the insurar has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/insurars")
    @Timed
    public ResponseEntity<InsurarDTO> createInsurar(@RequestBody InsurarDTO insurarDTO) throws URISyntaxException {
        log.debug("REST request to save Insurar : {}", insurarDTO);
      
        InsurerDTO insurerDTO = new InsurerDTO(insurarDTO.getInsurarName());
      
        api.createInsurerUsingPOST(insurerDTO);
        
        if (insurarDTO.getId() != null) {
            throw new BadRequestAlertException("A new insurar cannot already have an ID", ENTITY_NAME, "idexists");
        }
        InsurarDTO result = insurarService.save(insurarDTO);
        return ResponseEntity.created(new URI("/api/insurars/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /insurars : Updates an existing insurar.
     *
     * @param insurarDTO the insurarDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated insurarDTO,
     * or with status 400 (Bad Request) if the insurarDTO is not valid,
     * or with status 500 (Internal Server Error) if the insurarDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/insurars")
    @Timed
    public ResponseEntity<InsurarDTO> updateInsurar(@RequestBody InsurarDTO insurarDTO) throws URISyntaxException {
        log.debug("REST request to update Insurar : {}", insurarDTO);
        InsurerDTO insurerDTO = new InsurerDTO(insurarDTO.getInsurarName());
        	api.updateInsurerUsingPUT(insurerDTO);
        	 if (insurarDTO.getId() == null) {
                 return createInsurar(insurarDTO);
             }
             InsurarDTO result = insurarService.save(insurarDTO);
             return ResponseEntity.ok()
                 .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, insurarDTO.getId().toString()))
                 .body(result);
    }

    /**
     * GET  /insurars : get all the insurars.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of insurars in body
     */
    @GetMapping("/insurars")
    @Timed
    public ResponseEntity<List<InsurerDTO>> getAllInsurars(Integer page,Integer size ,ArrayList<String> sort) {
        log.debug("REST request to get a page of Insurars");
     return api.getAllInsurersUsingGET(page, size, sort);
    }

    /**
     * GET  /insurars/:id : get the "id" insurar.
     *
     * @param id the id of the insurarDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the insurarDTO, or with status 404 (Not Found)
     */
    @GetMapping("/insurars/{id}")
    @Timed
    public ResponseEntity<InsurerDTO> getInsurar(@PathVariable Long id) {
        log.debug("REST request to get Insurar : {}", id);
       return api.getInsurerUsingGET(id);
    }

  public InsurarModel getInsurar(Insurar insurar){
    	
    	Long id=insurar.getId();
    	List<HealthInsuranceDTO> healthDTO=insurarService.findByHealthInsurances_Insurar_Id(id,new PageRequest(0, 2)).getContent();
    	List<HealthInsuranceModel> healthList=new ArrayList<>();
    	InsurarModel insurarModel=null;
    	if(healthDTO!=null){
     		
     		List<HealthInsurance> health=healthMapper.toEntity(healthDTO);
     		
     		for(HealthInsurance h:health){
     		HealthInsuranceModel healthMarshaled=new HealthInsuranceModel(h.getId(),h.getInsuranceNumber(),h.getExpiraryDate());
     		healthList.add(healthMarshaled);
     		
     		 insurarModel=new InsurarModel(id,insurar.getInsurarName(),healthList);
     		}
    	}	
     		 return insurarModel;
    }
    /**
     * DELETE  /insurars/:id : delete the "id" insurar.
     *
     * @param id the id of the insurarDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/insurars/{id}")
    @Timed
    public ResponseEntity<Void> deleteInsurar(@PathVariable Long id) {
        log.debug("REST request to delete Insurar : {}", id);
       return api.deleteInsurerUsingDELETE(id);
    }
    
    
    /**
     * GET  /insurars/findByHealthInsurance_Insurar_Id/{id}:relationShip : get the "id" prescription.
     *
     * @param id the id of the prescriptionDTOs to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the prescriptionDTO, or with status 404 (Not Found)
     */
    @GetMapping("/insurars/findByHealthInsurances_Insurar_Id/{id}")
    @Timed
    public ResponseEntity<List<HealthInsuranceDTO>> getHealthInsuranceBy_Insurar_Id(@PathVariable Long id,Pageable pageable) {
        log.debug("REST request to get Prescription : {}",id);
        Page<HealthInsuranceDTO> familyRelationShipDTO = insurarService.findByHealthInsurances_Insurar_Id(id,pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(familyRelationShipDTO,"/api/insurars/findByHealthInsurance_Insurar_Id/{id}");
        return new ResponseEntity<>(familyRelationShipDTO.getContent(), headers, HttpStatus.OK);
    }
    
    
}
