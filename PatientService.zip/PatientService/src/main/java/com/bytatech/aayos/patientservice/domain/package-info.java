/**
 * JPA domain objects.
 */
package com.bytatech.aayos.patientservice.domain;
