package com.bytatech.aayos.patientservice.domain;

import io.swagger.annotations.ApiModel;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Objects;

/**
 * The FamilyRelationShip entity.
 * @author MayaSanjeev.
 */
@ApiModel(description = "The FamilyRelationShip entity. @author MayaSanjeev.")
@Entity
@Table(name = "family_relation_ship")
public class FamilyRelationShip implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "relation_ship")
    private String relationShip;

    @ManyToOne
    private Patient patient;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRelationShip() {
        return relationShip;
    }

    public FamilyRelationShip relationShip(String relationShip) {
        this.relationShip = relationShip;
        return this;
    }

    public void setRelationShip(String relationShip) {
        this.relationShip = relationShip;
    }

    public Patient getPatient() {
        return patient;
    }

    public FamilyRelationShip patient(Patient patient) {
        this.patient = patient;
        return this;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        FamilyRelationShip familyRelationShip = (FamilyRelationShip) o;
        if (familyRelationShip.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), familyRelationShip.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "FamilyRelationShip{" +
            "id=" + getId() +
            ", relationShip='" + getRelationShip() + "'" +
            "}";
    }
}
