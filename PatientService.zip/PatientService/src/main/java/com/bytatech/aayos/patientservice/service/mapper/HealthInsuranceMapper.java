package com.bytatech.aayos.patientservice.service.mapper;

import com.bytatech.aayos.patientservice.domain.*;
import com.bytatech.aayos.patientservice.service.dto.HealthInsuranceDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity HealthInsurance and its DTO HealthInsuranceDTO.
 */
@Mapper(componentModel = "spring", uses = {InsurarMapper.class})
public interface HealthInsuranceMapper extends EntityMapper<HealthInsuranceDTO, HealthInsurance> {

    @Mapping(source = "insurar.id", target = "insurarId")
    HealthInsuranceDTO toDto(HealthInsurance healthInsurance); 

    @Mapping(source = "insurarId", target = "insurar")
    HealthInsurance toEntity(HealthInsuranceDTO healthInsuranceDTO);

    default HealthInsurance fromId(Long id) {
        if (id == null) {
            return null;
        }
        HealthInsurance healthInsurance = new HealthInsurance();
        healthInsurance.setId(id);
        return healthInsurance;
    }
}
