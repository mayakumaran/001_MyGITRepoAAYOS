package com.bytatech.aayos.patientservice.service.dto;


import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A DTO for the FamilyRelationShip entity.
 */
public class FamilyRelationShipDTO implements Serializable {

    private Long id;

    private String relationShip;

    private Long patientId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRelationShip() {
        return relationShip;
    }

    public void setRelationShip(String relationShip) {
        this.relationShip = relationShip;
    }

    public Long getPatientId() {
        return patientId;
    }

    public void setPatientId(Long patientId) {
        this.patientId = patientId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        FamilyRelationShipDTO familyRelationShipDTO = (FamilyRelationShipDTO) o;
        if(familyRelationShipDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), familyRelationShipDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "FamilyRelationShipDTO{" +
            "id=" + getId() +
            ", relationShip='" + getRelationShip() + "'" +
            "}";
    }
}
