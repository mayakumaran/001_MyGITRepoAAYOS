package com.bytatech.aayos.patientservice.service.impl;

import com.bytatech.aayos.patientservice.service.HealthInsuranceService;
import com.bytatech.aayos.patientservice.domain.HealthInsurance;
import com.bytatech.aayos.patientservice.repository.HealthInsuranceRepository;
import com.bytatech.aayos.patientservice.service.dto.HealthInsuranceDTO;
import com.bytatech.aayos.patientservice.service.mapper.HealthInsuranceMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * Service Implementation for managing HealthInsurance.
 */
@Service
@Transactional
public class HealthInsuranceServiceImpl implements HealthInsuranceService{

    private final Logger log = LoggerFactory.getLogger(HealthInsuranceServiceImpl.class);

    private final HealthInsuranceRepository healthInsuranceRepository;

    private final HealthInsuranceMapper healthInsuranceMapper;

    public HealthInsuranceServiceImpl(HealthInsuranceRepository healthInsuranceRepository, HealthInsuranceMapper healthInsuranceMapper) {
        this.healthInsuranceRepository = healthInsuranceRepository;
        this.healthInsuranceMapper = healthInsuranceMapper;
    }

    /**
     * Save a healthInsurance.
     *
     * @param healthInsuranceDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public HealthInsuranceDTO save(HealthInsuranceDTO healthInsuranceDTO) {
        log.debug("Request to save HealthInsurance : {}", healthInsuranceDTO);
        HealthInsurance healthInsurance = healthInsuranceMapper.toEntity(healthInsuranceDTO);
        healthInsurance = healthInsuranceRepository.save(healthInsurance);
        return healthInsuranceMapper.toDto(healthInsurance);
    }

    /**
     * Get all the healthInsurances.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<HealthInsuranceDTO> findAll(Pageable pageable) {
        log.debug("Request to get all HealthInsurances");
        return healthInsuranceRepository.findAll(pageable)
            .map(healthInsuranceMapper::toDto);
    }

    /**
     * Get one healthInsurance by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public HealthInsuranceDTO findOne(Long id) {
        log.debug("Request to get HealthInsurance : {}", id);
        HealthInsurance healthInsurance = healthInsuranceRepository.findOne(id);
        return healthInsuranceMapper.toDto(healthInsurance);
    }

    /**
     * Delete the healthInsurance by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete HealthInsurance : {}", id);
        healthInsuranceRepository.delete(id);
    }
}
