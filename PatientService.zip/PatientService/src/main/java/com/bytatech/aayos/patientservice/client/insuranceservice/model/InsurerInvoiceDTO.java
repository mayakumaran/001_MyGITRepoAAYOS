package com.bytatech.aayos.patientservice.client.insuranceservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;

/**
 * InsurerInvoiceDTO
 */
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2018-03-14T11:48:59.500+05:30")

public class InsurerInvoiceDTO   {
  @JsonProperty("departmentId")
  private Long departmentId = null;

  @JsonProperty("endDate")
  private LocalDate endDate = null;

  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("insurerId")
  private Long insurerId = null;

  @JsonProperty("insurerInvoiceStatusId")
  private Long insurerInvoiceStatusId = null;

  @JsonProperty("invoiceDate")
  private LocalDate invoiceDate = null;

  @JsonProperty("invoiceNumber")
  private Long invoiceNumber = null;

  @JsonProperty("startDate")
  private LocalDate startDate = null;

  public InsurerInvoiceDTO departmentId(Long departmentId) {
    this.departmentId = departmentId;
    return this;
  }

   /**
   * Get departmentId
   * @return departmentId
  **/
  @ApiModelProperty(value = "")
  public Long getDepartmentId() {
    return departmentId;
  }

  public void setDepartmentId(Long departmentId) {
    this.departmentId = departmentId;
  }

  public InsurerInvoiceDTO endDate(LocalDate endDate) {
    this.endDate = endDate;
    return this;
  }

   /**
   * Get endDate
   * @return endDate
  **/
  @ApiModelProperty(value = "")
  public LocalDate getEndDate() {
    return endDate;
  }

  public void setEndDate(LocalDate endDate) {
    this.endDate = endDate;
  }

  public InsurerInvoiceDTO id(Long id) {
    this.id = id;
    return this;
  }

   /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(value = "")
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public InsurerInvoiceDTO insurerId(Long insurerId) {
    this.insurerId = insurerId;
    return this;
  }

   /**
   * Get insurerId
   * @return insurerId
  **/
  @ApiModelProperty(value = "")
  public Long getInsurerId() {
    return insurerId;
  }

  public void setInsurerId(Long insurerId) {
    this.insurerId = insurerId;
  }

  public InsurerInvoiceDTO insurerInvoiceStatusId(Long insurerInvoiceStatusId) {
    this.insurerInvoiceStatusId = insurerInvoiceStatusId;
    return this;
  }

   /**
   * Get insurerInvoiceStatusId
   * @return insurerInvoiceStatusId
  **/
  @ApiModelProperty(value = "")
  public Long getInsurerInvoiceStatusId() {
    return insurerInvoiceStatusId;
  }

  public void setInsurerInvoiceStatusId(Long insurerInvoiceStatusId) {
    this.insurerInvoiceStatusId = insurerInvoiceStatusId;
  }

  public InsurerInvoiceDTO invoiceDate(LocalDate invoiceDate) {
    this.invoiceDate = invoiceDate;
    return this;
  }

   /**
   * Get invoiceDate
   * @return invoiceDate
  **/
  @ApiModelProperty(value = "")
  public LocalDate getInvoiceDate() {
    return invoiceDate;
  }

  public void setInvoiceDate(LocalDate invoiceDate) {
    this.invoiceDate = invoiceDate;
  }

  public InsurerInvoiceDTO invoiceNumber(Long invoiceNumber) {
    this.invoiceNumber = invoiceNumber;
    return this;
  }

   /**
   * Get invoiceNumber
   * @return invoiceNumber
  **/
  @ApiModelProperty(value = "")
  public Long getInvoiceNumber() {
    return invoiceNumber;
  }

  public void setInvoiceNumber(Long invoiceNumber) {
    this.invoiceNumber = invoiceNumber;
  }

  public InsurerInvoiceDTO startDate(LocalDate startDate) {
    this.startDate = startDate;
    return this;
  }

   /**
   * Get startDate
   * @return startDate
  **/
  @ApiModelProperty(value = "")
  public LocalDate getStartDate() {
    return startDate;
  }

  public void setStartDate(LocalDate startDate) {
    this.startDate = startDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InsurerInvoiceDTO insurerInvoiceDTO = (InsurerInvoiceDTO) o;
    return Objects.equals(this.departmentId, insurerInvoiceDTO.departmentId) &&
        Objects.equals(this.endDate, insurerInvoiceDTO.endDate) &&
        Objects.equals(this.id, insurerInvoiceDTO.id) &&
        Objects.equals(this.insurerId, insurerInvoiceDTO.insurerId) &&
        Objects.equals(this.insurerInvoiceStatusId, insurerInvoiceDTO.insurerInvoiceStatusId) &&
        Objects.equals(this.invoiceDate, insurerInvoiceDTO.invoiceDate) &&
        Objects.equals(this.invoiceNumber, insurerInvoiceDTO.invoiceNumber) &&
        Objects.equals(this.startDate, insurerInvoiceDTO.startDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(departmentId, endDate, id, insurerId, insurerInvoiceStatusId, invoiceDate, invoiceNumber, startDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InsurerInvoiceDTO {\n");
    
    sb.append("    departmentId: ").append(toIndentedString(departmentId)).append("\n");
    sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    insurerId: ").append(toIndentedString(insurerId)).append("\n");
    sb.append("    insurerInvoiceStatusId: ").append(toIndentedString(insurerInvoiceStatusId)).append("\n");
    sb.append("    invoiceDate: ").append(toIndentedString(invoiceDate)).append("\n");
    sb.append("    invoiceNumber: ").append(toIndentedString(invoiceNumber)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

