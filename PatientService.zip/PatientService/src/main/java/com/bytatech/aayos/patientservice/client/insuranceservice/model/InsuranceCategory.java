package com.bytatech.aayos.patientservice.client.insuranceservice.model;

import java.util.Objects;
import com.bytatech.aayos.patientservice.client.insuranceservice.model.CoveredActivity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;

/**
 * InsuranceCategory
 */
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2018-03-14T11:48:59.500+05:30")

public class InsuranceCategory   {
  @JsonProperty("categoryName")
  private String categoryName = null;

  @JsonProperty("coveredActivityns")
  private List<CoveredActivity> coveredActivityns = new ArrayList<CoveredActivity>();

  @JsonProperty("id")
  private Long id = null;

  public InsuranceCategory categoryName(String categoryName) {
    this.categoryName = categoryName;
    return this;
  }

   /**
   * Get categoryName
   * @return categoryName
  **/
  @ApiModelProperty(value = "")
  public String getCategoryName() {
    return categoryName;
  }

  public void setCategoryName(String categoryName) {
    this.categoryName = categoryName;
  }

  public InsuranceCategory coveredActivityns(List<CoveredActivity> coveredActivityns) {
    this.coveredActivityns = coveredActivityns;
    return this;
  }

  public InsuranceCategory addCoveredActivitynsItem(CoveredActivity coveredActivitynsItem) {
    this.coveredActivityns.add(coveredActivitynsItem);
    return this;
  }

   /**
   * Get coveredActivityns
   * @return coveredActivityns
  **/
  @ApiModelProperty(value = "")
  public List<CoveredActivity> getCoveredActivityns() {
    return coveredActivityns;
  }

  public void setCoveredActivityns(List<CoveredActivity> coveredActivityns) {
    this.coveredActivityns = coveredActivityns;
  }

  public InsuranceCategory id(Long id) {
    this.id = id;
    return this;
  }

   /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(value = "")
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InsuranceCategory insuranceCategory = (InsuranceCategory) o;
    return Objects.equals(this.categoryName, insuranceCategory.categoryName) &&
        Objects.equals(this.coveredActivityns, insuranceCategory.coveredActivityns) &&
        Objects.equals(this.id, insuranceCategory.id);
  }

  @Override
  public int hashCode() {
    return Objects.hash(categoryName, coveredActivityns, id);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InsuranceCategory {\n");
    
    sb.append("    categoryName: ").append(toIndentedString(categoryName)).append("\n");
    sb.append("    coveredActivityns: ").append(toIndentedString(coveredActivityns)).append("\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

