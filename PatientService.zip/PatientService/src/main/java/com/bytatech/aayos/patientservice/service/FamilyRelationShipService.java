package com.bytatech.aayos.patientservice.service;

import com.bytatech.aayos.patientservice.service.dto.FamilyRelationShipDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing FamilyRelationShip.
 */
public interface FamilyRelationShipService {

    /**
     * Save a familyRelationShip.
     *
     * @param familyRelationShipDTO the entity to save
     * @return the persisted entity
     */
    FamilyRelationShipDTO save(FamilyRelationShipDTO familyRelationShipDTO);

    /**
     * Get all the familyRelationShips.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<FamilyRelationShipDTO> findAll(Pageable pageable);

    /**
     * Get the "id" familyRelationShip.
     *
     * @param id the id of the entity
     * @return the entity
     */
    FamilyRelationShipDTO findOne(Long id);

    /**
     * Delete the "id" familyRelationShip.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
