package com.bytatech.aayos.patientservice.repository;

import com.bytatech.aayos.patientservice.domain.FamilyRelationShip;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.*;


/**
 * Spring Data JPA repository for the FamilyRelationShip entity.
 */
@SuppressWarnings("unused")
@Repository
public interface FamilyRelationShipRepository extends JpaRepository<FamilyRelationShip, Long> {

}
