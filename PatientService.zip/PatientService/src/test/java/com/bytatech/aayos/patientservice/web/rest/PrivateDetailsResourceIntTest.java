package com.bytatech.aayos.patientservice.web.rest;

import com.bytatech.aayos.patientservice.PatientserviceApp;

import com.bytatech.aayos.patientservice.domain.PrivateDetails;
import com.bytatech.aayos.patientservice.repository.PrivateDetailsRepository;
import com.bytatech.aayos.patientservice.service.PrivateDetailsService;
import com.bytatech.aayos.patientservice.service.dto.PrivateDetailsDTO;
import com.bytatech.aayos.patientservice.service.mapper.PrivateDetailsMapper;
import com.bytatech.aayos.patientservice.web.rest.errors.ExceptionTranslator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.util.List;

import static com.bytatech.aayos.patientservice.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the PrivateDetailsResource REST controller.
 *
 * @see PrivateDetailsResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = PatientserviceApp.class)
public class PrivateDetailsResourceIntTest {

    private static final String DEFAULT_EMAIL = "AAAAAAAAAA";
    private static final String UPDATED_EMAIL = "BBBBBBBBBB";

    private static final String DEFAULT_ADDRESS = "AAAAAAAAAA";
    private static final String UPDATED_ADDRESS = "BBBBBBBBBB";

    private static final String DEFAULT_TOWN = "AAAAAAAAAA";
    private static final String UPDATED_TOWN = "BBBBBBBBBB";

    private static final Integer DEFAULT_ZIP_CODE = 1;
    private static final Integer UPDATED_ZIP_CODE = 2;

    private static final String DEFAULT_SOCIAL_MEDIA = "AAAAAAAAAA";
    private static final String UPDATED_SOCIAL_MEDIA = "BBBBBBBBBB";

    @Autowired
    private PrivateDetailsRepository privateDetailsRepository;

    @Autowired
    private PrivateDetailsMapper privateDetailsMapper;

    @Autowired
    private PrivateDetailsService privateDetailsService;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    private MockMvc restPrivateDetailsMockMvc;

    private PrivateDetails privateDetails;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final PrivateDetailsResource privateDetailsResource = new PrivateDetailsResource(privateDetailsService);
        this.restPrivateDetailsMockMvc = MockMvcBuilders.standaloneSetup(privateDetailsResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static PrivateDetails createEntity(EntityManager em) {
        PrivateDetails privateDetails = new PrivateDetails()
            .email(DEFAULT_EMAIL)
            .address(DEFAULT_ADDRESS)
            .town(DEFAULT_TOWN)
            .zipCode(DEFAULT_ZIP_CODE)
            .socialMedia(DEFAULT_SOCIAL_MEDIA);
        return privateDetails;
    }

    @Before
    public void initTest() {
        privateDetails = createEntity(em);
    }

    @Test
    @Transactional
    public void createPrivateDetails() throws Exception {
        int databaseSizeBeforeCreate = privateDetailsRepository.findAll().size();

        // Create the PrivateDetails
        PrivateDetailsDTO privateDetailsDTO = privateDetailsMapper.toDto(privateDetails);
        restPrivateDetailsMockMvc.perform(post("/api/private-details")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(privateDetailsDTO)))
            .andExpect(status().isCreated());

        // Validate the PrivateDetails in the database
        List<PrivateDetails> privateDetailsList = privateDetailsRepository.findAll();
        assertThat(privateDetailsList).hasSize(databaseSizeBeforeCreate + 1);
        PrivateDetails testPrivateDetails = privateDetailsList.get(privateDetailsList.size() - 1);
        assertThat(testPrivateDetails.getEmail()).isEqualTo(DEFAULT_EMAIL);
        assertThat(testPrivateDetails.getAddress()).isEqualTo(DEFAULT_ADDRESS);
        assertThat(testPrivateDetails.getTown()).isEqualTo(DEFAULT_TOWN);
        assertThat(testPrivateDetails.getZipCode()).isEqualTo(DEFAULT_ZIP_CODE);
        assertThat(testPrivateDetails.getSocialMedia()).isEqualTo(DEFAULT_SOCIAL_MEDIA);
    }

    @Test
    @Transactional
    public void createPrivateDetailsWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = privateDetailsRepository.findAll().size();

        // Create the PrivateDetails with an existing ID
        privateDetails.setId(1L);
        PrivateDetailsDTO privateDetailsDTO = privateDetailsMapper.toDto(privateDetails);

        // An entity with an existing ID cannot be created, so this API call must fail
        restPrivateDetailsMockMvc.perform(post("/api/private-details")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(privateDetailsDTO)))
            .andExpect(status().isBadRequest());

        // Validate the PrivateDetails in the database
        List<PrivateDetails> privateDetailsList = privateDetailsRepository.findAll();
        assertThat(privateDetailsList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void getAllPrivateDetails() throws Exception {
        // Initialize the database
        privateDetailsRepository.saveAndFlush(privateDetails);

        // Get all the privateDetailsList
        restPrivateDetailsMockMvc.perform(get("/api/private-details?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(privateDetails.getId().intValue())))
            .andExpect(jsonPath("$.[*].email").value(hasItem(DEFAULT_EMAIL.toString())))
            .andExpect(jsonPath("$.[*].address").value(hasItem(DEFAULT_ADDRESS.toString())))
            .andExpect(jsonPath("$.[*].town").value(hasItem(DEFAULT_TOWN.toString())))
            .andExpect(jsonPath("$.[*].zipCode").value(hasItem(DEFAULT_ZIP_CODE)))
            .andExpect(jsonPath("$.[*].socialMedia").value(hasItem(DEFAULT_SOCIAL_MEDIA.toString())));
    }

    @Test
    @Transactional
    public void getPrivateDetails() throws Exception {
        // Initialize the database
        privateDetailsRepository.saveAndFlush(privateDetails);

        // Get the privateDetails
        restPrivateDetailsMockMvc.perform(get("/api/private-details/{id}", privateDetails.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(privateDetails.getId().intValue()))
            .andExpect(jsonPath("$.email").value(DEFAULT_EMAIL.toString()))
            .andExpect(jsonPath("$.address").value(DEFAULT_ADDRESS.toString()))
            .andExpect(jsonPath("$.town").value(DEFAULT_TOWN.toString()))
            .andExpect(jsonPath("$.zipCode").value(DEFAULT_ZIP_CODE))
            .andExpect(jsonPath("$.socialMedia").value(DEFAULT_SOCIAL_MEDIA.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingPrivateDetails() throws Exception {
        // Get the privateDetails
        restPrivateDetailsMockMvc.perform(get("/api/private-details/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updatePrivateDetails() throws Exception {
        // Initialize the database
        privateDetailsRepository.saveAndFlush(privateDetails);
        int databaseSizeBeforeUpdate = privateDetailsRepository.findAll().size();

        // Update the privateDetails
        PrivateDetails updatedPrivateDetails = privateDetailsRepository.findOne(privateDetails.getId());
        // Disconnect from session so that the updates on updatedPrivateDetails are not directly saved in db
        em.detach(updatedPrivateDetails);
        updatedPrivateDetails
            .email(UPDATED_EMAIL)
            .address(UPDATED_ADDRESS)
            .town(UPDATED_TOWN)
            .zipCode(UPDATED_ZIP_CODE)
            .socialMedia(UPDATED_SOCIAL_MEDIA);
        PrivateDetailsDTO privateDetailsDTO = privateDetailsMapper.toDto(updatedPrivateDetails);

        restPrivateDetailsMockMvc.perform(put("/api/private-details")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(privateDetailsDTO)))
            .andExpect(status().isOk());

        // Validate the PrivateDetails in the database
        List<PrivateDetails> privateDetailsList = privateDetailsRepository.findAll();
        assertThat(privateDetailsList).hasSize(databaseSizeBeforeUpdate);
        PrivateDetails testPrivateDetails = privateDetailsList.get(privateDetailsList.size() - 1);
        assertThat(testPrivateDetails.getEmail()).isEqualTo(UPDATED_EMAIL);
        assertThat(testPrivateDetails.getAddress()).isEqualTo(UPDATED_ADDRESS);
        assertThat(testPrivateDetails.getTown()).isEqualTo(UPDATED_TOWN);
        assertThat(testPrivateDetails.getZipCode()).isEqualTo(UPDATED_ZIP_CODE);
        assertThat(testPrivateDetails.getSocialMedia()).isEqualTo(UPDATED_SOCIAL_MEDIA);
    }

    @Test
    @Transactional
    public void updateNonExistingPrivateDetails() throws Exception {
        int databaseSizeBeforeUpdate = privateDetailsRepository.findAll().size();

        // Create the PrivateDetails
        PrivateDetailsDTO privateDetailsDTO = privateDetailsMapper.toDto(privateDetails);

        // If the entity doesn't have an ID, it will be created instead of just being updated
        restPrivateDetailsMockMvc.perform(put("/api/private-details")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(privateDetailsDTO)))
            .andExpect(status().isCreated());

        // Validate the PrivateDetails in the database
        List<PrivateDetails> privateDetailsList = privateDetailsRepository.findAll();
        assertThat(privateDetailsList).hasSize(databaseSizeBeforeUpdate + 1);
    }

    @Test
    @Transactional
    public void deletePrivateDetails() throws Exception {
        // Initialize the database
        privateDetailsRepository.saveAndFlush(privateDetails);
        int databaseSizeBeforeDelete = privateDetailsRepository.findAll().size();

        // Get the privateDetails
        restPrivateDetailsMockMvc.perform(delete("/api/private-details/{id}", privateDetails.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<PrivateDetails> privateDetailsList = privateDetailsRepository.findAll();
        assertThat(privateDetailsList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(PrivateDetails.class);
        PrivateDetails privateDetails1 = new PrivateDetails();
        privateDetails1.setId(1L);
        PrivateDetails privateDetails2 = new PrivateDetails();
        privateDetails2.setId(privateDetails1.getId());
        assertThat(privateDetails1).isEqualTo(privateDetails2);
        privateDetails2.setId(2L);
        assertThat(privateDetails1).isNotEqualTo(privateDetails2);
        privateDetails1.setId(null);
        assertThat(privateDetails1).isNotEqualTo(privateDetails2);
    }

    @Test
    @Transactional
    public void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(PrivateDetailsDTO.class);
        PrivateDetailsDTO privateDetailsDTO1 = new PrivateDetailsDTO();
        privateDetailsDTO1.setId(1L);
        PrivateDetailsDTO privateDetailsDTO2 = new PrivateDetailsDTO();
        assertThat(privateDetailsDTO1).isNotEqualTo(privateDetailsDTO2);
        privateDetailsDTO2.setId(privateDetailsDTO1.getId());
        assertThat(privateDetailsDTO1).isEqualTo(privateDetailsDTO2);
        privateDetailsDTO2.setId(2L);
        assertThat(privateDetailsDTO1).isNotEqualTo(privateDetailsDTO2);
        privateDetailsDTO1.setId(null);
        assertThat(privateDetailsDTO1).isNotEqualTo(privateDetailsDTO2);
    }

    @Test
    @Transactional
    public void testEntityFromId() {
        assertThat(privateDetailsMapper.fromId(42L).getId()).isEqualTo(42);
        assertThat(privateDetailsMapper.fromId(null)).isNull();
    }
}
