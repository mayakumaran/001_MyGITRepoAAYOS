package com.bytatech.aayos.patientservice.web.rest;

import com.bytatech.aayos.patientservice.PatientserviceApp;

import com.bytatech.aayos.patientservice.domain.FamilyRelationShip;
import com.bytatech.aayos.patientservice.repository.FamilyRelationShipRepository;
import com.bytatech.aayos.patientservice.service.FamilyRelationShipService;
import com.bytatech.aayos.patientservice.service.dto.FamilyRelationShipDTO;
import com.bytatech.aayos.patientservice.service.mapper.FamilyRelationShipMapper;
import com.bytatech.aayos.patientservice.web.rest.errors.ExceptionTranslator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.util.List;

import static com.bytatech.aayos.patientservice.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the FamilyRelationShipResource REST controller.
 *
 * @see FamilyRelationShipResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = PatientserviceApp.class)
public class FamilyRelationShipResourceIntTest {

    private static final String DEFAULT_RELATION_SHIP = "AAAAAAAAAA";
    private static final String UPDATED_RELATION_SHIP = "BBBBBBBBBB";

    @Autowired
    private FamilyRelationShipRepository familyRelationShipRepository;

    @Autowired
    private FamilyRelationShipMapper familyRelationShipMapper;

    @Autowired
    private FamilyRelationShipService familyRelationShipService;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    private MockMvc restFamilyRelationShipMockMvc;

    private FamilyRelationShip familyRelationShip;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final FamilyRelationShipResource familyRelationShipResource = new FamilyRelationShipResource(familyRelationShipService);
        this.restFamilyRelationShipMockMvc = MockMvcBuilders.standaloneSetup(familyRelationShipResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static FamilyRelationShip createEntity(EntityManager em) {
        FamilyRelationShip familyRelationShip = new FamilyRelationShip()
            .relationShip(DEFAULT_RELATION_SHIP);
        return familyRelationShip;
    }

    @Before
    public void initTest() {
        familyRelationShip = createEntity(em);
    }

    @Test
    @Transactional
    public void createFamilyRelationShip() throws Exception {
        int databaseSizeBeforeCreate = familyRelationShipRepository.findAll().size();

        // Create the FamilyRelationShip
        FamilyRelationShipDTO familyRelationShipDTO = familyRelationShipMapper.toDto(familyRelationShip);
        restFamilyRelationShipMockMvc.perform(post("/api/family-relation-ships")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(familyRelationShipDTO)))
            .andExpect(status().isCreated());

        // Validate the FamilyRelationShip in the database
        List<FamilyRelationShip> familyRelationShipList = familyRelationShipRepository.findAll();
        assertThat(familyRelationShipList).hasSize(databaseSizeBeforeCreate + 1);
        FamilyRelationShip testFamilyRelationShip = familyRelationShipList.get(familyRelationShipList.size() - 1);
        assertThat(testFamilyRelationShip.getRelationShip()).isEqualTo(DEFAULT_RELATION_SHIP);
    }

    @Test
    @Transactional
    public void createFamilyRelationShipWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = familyRelationShipRepository.findAll().size();

        // Create the FamilyRelationShip with an existing ID
        familyRelationShip.setId(1L);
        FamilyRelationShipDTO familyRelationShipDTO = familyRelationShipMapper.toDto(familyRelationShip);

        // An entity with an existing ID cannot be created, so this API call must fail
        restFamilyRelationShipMockMvc.perform(post("/api/family-relation-ships")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(familyRelationShipDTO)))
            .andExpect(status().isBadRequest());

        // Validate the FamilyRelationShip in the database
        List<FamilyRelationShip> familyRelationShipList = familyRelationShipRepository.findAll();
        assertThat(familyRelationShipList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void getAllFamilyRelationShips() throws Exception {
        // Initialize the database
        familyRelationShipRepository.saveAndFlush(familyRelationShip);

        // Get all the familyRelationShipList
        restFamilyRelationShipMockMvc.perform(get("/api/family-relation-ships?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(familyRelationShip.getId().intValue())))
            .andExpect(jsonPath("$.[*].relationShip").value(hasItem(DEFAULT_RELATION_SHIP.toString())));
    }

    @Test
    @Transactional
    public void getFamilyRelationShip() throws Exception {
        // Initialize the database
        familyRelationShipRepository.saveAndFlush(familyRelationShip);

        // Get the familyRelationShip
        restFamilyRelationShipMockMvc.perform(get("/api/family-relation-ships/{id}", familyRelationShip.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(familyRelationShip.getId().intValue()))
            .andExpect(jsonPath("$.relationShip").value(DEFAULT_RELATION_SHIP.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingFamilyRelationShip() throws Exception {
        // Get the familyRelationShip
        restFamilyRelationShipMockMvc.perform(get("/api/family-relation-ships/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateFamilyRelationShip() throws Exception {
        // Initialize the database
        familyRelationShipRepository.saveAndFlush(familyRelationShip);
        int databaseSizeBeforeUpdate = familyRelationShipRepository.findAll().size();

        // Update the familyRelationShip
        FamilyRelationShip updatedFamilyRelationShip = familyRelationShipRepository.findOne(familyRelationShip.getId());
        // Disconnect from session so that the updates on updatedFamilyRelationShip are not directly saved in db
        em.detach(updatedFamilyRelationShip);
        updatedFamilyRelationShip
            .relationShip(UPDATED_RELATION_SHIP);
        FamilyRelationShipDTO familyRelationShipDTO = familyRelationShipMapper.toDto(updatedFamilyRelationShip);

        restFamilyRelationShipMockMvc.perform(put("/api/family-relation-ships")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(familyRelationShipDTO)))
            .andExpect(status().isOk());

        // Validate the FamilyRelationShip in the database
        List<FamilyRelationShip> familyRelationShipList = familyRelationShipRepository.findAll();
        assertThat(familyRelationShipList).hasSize(databaseSizeBeforeUpdate);
        FamilyRelationShip testFamilyRelationShip = familyRelationShipList.get(familyRelationShipList.size() - 1);
        assertThat(testFamilyRelationShip.getRelationShip()).isEqualTo(UPDATED_RELATION_SHIP);
    }

    @Test
    @Transactional
    public void updateNonExistingFamilyRelationShip() throws Exception {
        int databaseSizeBeforeUpdate = familyRelationShipRepository.findAll().size();

        // Create the FamilyRelationShip
        FamilyRelationShipDTO familyRelationShipDTO = familyRelationShipMapper.toDto(familyRelationShip);

        // If the entity doesn't have an ID, it will be created instead of just being updated
        restFamilyRelationShipMockMvc.perform(put("/api/family-relation-ships")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(familyRelationShipDTO)))
            .andExpect(status().isCreated());

        // Validate the FamilyRelationShip in the database
        List<FamilyRelationShip> familyRelationShipList = familyRelationShipRepository.findAll();
        assertThat(familyRelationShipList).hasSize(databaseSizeBeforeUpdate + 1);
    }

    @Test
    @Transactional
    public void deleteFamilyRelationShip() throws Exception {
        // Initialize the database
        familyRelationShipRepository.saveAndFlush(familyRelationShip);
        int databaseSizeBeforeDelete = familyRelationShipRepository.findAll().size();

        // Get the familyRelationShip
        restFamilyRelationShipMockMvc.perform(delete("/api/family-relation-ships/{id}", familyRelationShip.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<FamilyRelationShip> familyRelationShipList = familyRelationShipRepository.findAll();
        assertThat(familyRelationShipList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(FamilyRelationShip.class);
        FamilyRelationShip familyRelationShip1 = new FamilyRelationShip();
        familyRelationShip1.setId(1L);
        FamilyRelationShip familyRelationShip2 = new FamilyRelationShip();
        familyRelationShip2.setId(familyRelationShip1.getId());
        assertThat(familyRelationShip1).isEqualTo(familyRelationShip2);
        familyRelationShip2.setId(2L);
        assertThat(familyRelationShip1).isNotEqualTo(familyRelationShip2);
        familyRelationShip1.setId(null);
        assertThat(familyRelationShip1).isNotEqualTo(familyRelationShip2);
    }

    @Test
    @Transactional
    public void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(FamilyRelationShipDTO.class);
        FamilyRelationShipDTO familyRelationShipDTO1 = new FamilyRelationShipDTO();
        familyRelationShipDTO1.setId(1L);
        FamilyRelationShipDTO familyRelationShipDTO2 = new FamilyRelationShipDTO();
        assertThat(familyRelationShipDTO1).isNotEqualTo(familyRelationShipDTO2);
        familyRelationShipDTO2.setId(familyRelationShipDTO1.getId());
        assertThat(familyRelationShipDTO1).isEqualTo(familyRelationShipDTO2);
        familyRelationShipDTO2.setId(2L);
        assertThat(familyRelationShipDTO1).isNotEqualTo(familyRelationShipDTO2);
        familyRelationShipDTO1.setId(null);
        assertThat(familyRelationShipDTO1).isNotEqualTo(familyRelationShipDTO2);
    }

    @Test
    @Transactional
    public void testEntityFromId() {
        assertThat(familyRelationShipMapper.fromId(42L).getId()).isEqualTo(42);
        assertThat(familyRelationShipMapper.fromId(null)).isNull();
    }
}
