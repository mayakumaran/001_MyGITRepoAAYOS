package com.bytatech.aayos.patientservice.web.rest;

import com.bytatech.aayos.patientservice.PatientserviceApp;

import com.bytatech.aayos.patientservice.domain.Insurar;
import com.bytatech.aayos.patientservice.repository.InsurarRepository;
import com.bytatech.aayos.patientservice.service.InsurarService;
import com.bytatech.aayos.patientservice.service.dto.InsurarDTO;
import com.bytatech.aayos.patientservice.service.mapper.InsurarMapper;
import com.bytatech.aayos.patientservice.web.rest.errors.ExceptionTranslator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.util.List;

import static com.bytatech.aayos.patientservice.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the InsurarResource REST controller.
 *
 * @see InsurarResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = PatientserviceApp.class)
public class InsurarResourceIntTest {

    private static final String DEFAULT_INSURAR_NAME = "AAAAAAAAAA";
    private static final String UPDATED_INSURAR_NAME = "BBBBBBBBBB";

    @Autowired
    private InsurarRepository insurarRepository;

    @Autowired
    private InsurarMapper insurarMapper;

    @Autowired
    private InsurarService insurarService;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    private MockMvc restInsurarMockMvc;

    private Insurar insurar;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final InsurarResource insurarResource = new InsurarResource(insurarService);
        this.restInsurarMockMvc = MockMvcBuilders.standaloneSetup(insurarResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Insurar createEntity(EntityManager em) {
        Insurar insurar = new Insurar()
            .insurarName(DEFAULT_INSURAR_NAME);
        return insurar;
    }

    @Before
    public void initTest() {
        insurar = createEntity(em);
    }

    @Test
    @Transactional
    public void createInsurar() throws Exception {
        int databaseSizeBeforeCreate = insurarRepository.findAll().size();

        // Create the Insurar
        InsurarDTO insurarDTO = insurarMapper.toDto(insurar);
        restInsurarMockMvc.perform(post("/api/insurars")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(insurarDTO)))
            .andExpect(status().isCreated());

        // Validate the Insurar in the database
        List<Insurar> insurarList = insurarRepository.findAll();
        assertThat(insurarList).hasSize(databaseSizeBeforeCreate + 1);
        Insurar testInsurar = insurarList.get(insurarList.size() - 1);
        assertThat(testInsurar.getInsurarName()).isEqualTo(DEFAULT_INSURAR_NAME);
    }

    @Test
    @Transactional
    public void createInsurarWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = insurarRepository.findAll().size();

        // Create the Insurar with an existing ID
        insurar.setId(1L);
        InsurarDTO insurarDTO = insurarMapper.toDto(insurar);

        // An entity with an existing ID cannot be created, so this API call must fail
        restInsurarMockMvc.perform(post("/api/insurars")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(insurarDTO)))
            .andExpect(status().isBadRequest());

        // Validate the Insurar in the database
        List<Insurar> insurarList = insurarRepository.findAll();
        assertThat(insurarList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void getAllInsurars() throws Exception {
        // Initialize the database
        insurarRepository.saveAndFlush(insurar);

        // Get all the insurarList
        restInsurarMockMvc.perform(get("/api/insurars?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(insurar.getId().intValue())))
            .andExpect(jsonPath("$.[*].insurarName").value(hasItem(DEFAULT_INSURAR_NAME.toString())));
    }

    @Test
    @Transactional
    public void getInsurar() throws Exception {
        // Initialize the database
        insurarRepository.saveAndFlush(insurar);

        // Get the insurar
        restInsurarMockMvc.perform(get("/api/insurars/{id}", insurar.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(insurar.getId().intValue()))
            .andExpect(jsonPath("$.insurarName").value(DEFAULT_INSURAR_NAME.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingInsurar() throws Exception {
        // Get the insurar
        restInsurarMockMvc.perform(get("/api/insurars/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateInsurar() throws Exception {
        // Initialize the database
        insurarRepository.saveAndFlush(insurar);
        int databaseSizeBeforeUpdate = insurarRepository.findAll().size();

        // Update the insurar
        Insurar updatedInsurar = insurarRepository.findOne(insurar.getId());
        // Disconnect from session so that the updates on updatedInsurar are not directly saved in db
        em.detach(updatedInsurar);
        updatedInsurar
            .insurarName(UPDATED_INSURAR_NAME);
        InsurarDTO insurarDTO = insurarMapper.toDto(updatedInsurar);

        restInsurarMockMvc.perform(put("/api/insurars")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(insurarDTO)))
            .andExpect(status().isOk());

        // Validate the Insurar in the database
        List<Insurar> insurarList = insurarRepository.findAll();
        assertThat(insurarList).hasSize(databaseSizeBeforeUpdate);
        Insurar testInsurar = insurarList.get(insurarList.size() - 1);
        assertThat(testInsurar.getInsurarName()).isEqualTo(UPDATED_INSURAR_NAME);
    }

    @Test
    @Transactional
    public void updateNonExistingInsurar() throws Exception {
        int databaseSizeBeforeUpdate = insurarRepository.findAll().size();

        // Create the Insurar
        InsurarDTO insurarDTO = insurarMapper.toDto(insurar);

        // If the entity doesn't have an ID, it will be created instead of just being updated
        restInsurarMockMvc.perform(put("/api/insurars")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(insurarDTO)))
            .andExpect(status().isCreated());

        // Validate the Insurar in the database
        List<Insurar> insurarList = insurarRepository.findAll();
        assertThat(insurarList).hasSize(databaseSizeBeforeUpdate + 1);
    }

    @Test
    @Transactional
    public void deleteInsurar() throws Exception {
        // Initialize the database
        insurarRepository.saveAndFlush(insurar);
        int databaseSizeBeforeDelete = insurarRepository.findAll().size();

        // Get the insurar
        restInsurarMockMvc.perform(delete("/api/insurars/{id}", insurar.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Insurar> insurarList = insurarRepository.findAll();
        assertThat(insurarList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Insurar.class);
        Insurar insurar1 = new Insurar();
        insurar1.setId(1L);
        Insurar insurar2 = new Insurar();
        insurar2.setId(insurar1.getId());
        assertThat(insurar1).isEqualTo(insurar2);
        insurar2.setId(2L);
        assertThat(insurar1).isNotEqualTo(insurar2);
        insurar1.setId(null);
        assertThat(insurar1).isNotEqualTo(insurar2);
    }

    @Test
    @Transactional
    public void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(InsurarDTO.class);
        InsurarDTO insurarDTO1 = new InsurarDTO();
        insurarDTO1.setId(1L);
        InsurarDTO insurarDTO2 = new InsurarDTO();
        assertThat(insurarDTO1).isNotEqualTo(insurarDTO2);
        insurarDTO2.setId(insurarDTO1.getId());
        assertThat(insurarDTO1).isEqualTo(insurarDTO2);
        insurarDTO2.setId(2L);
        assertThat(insurarDTO1).isNotEqualTo(insurarDTO2);
        insurarDTO1.setId(null);
        assertThat(insurarDTO1).isNotEqualTo(insurarDTO2);
    }

    @Test
    @Transactional
    public void testEntityFromId() {
        assertThat(insurarMapper.fromId(42L).getId()).isEqualTo(42);
        assertThat(insurarMapper.fromId(null)).isNull();
    }
}
